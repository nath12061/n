$(document).ready(function(){
	$('.main_select').styler();
});